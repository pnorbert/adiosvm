#include <vtkActor.h>
#include <vtkConeSource.h>
#include <vtkGraphicsFactory.h>
#include <vtkPolyDataMapper.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>

int main()
{
  vtkGraphicsFactory::SetOffScreenOnlyMode(1);

  vtkConeSource* cone = vtkConeSource::New();

  vtkPolyDataMapper* mapper = vtkPolyDataMapper::New();
  mapper->SetInput(cone->GetOutput());
  cone->Delete();

  vtkActor* actor = vtkActor::New();
  actor->SetMapper(mapper);
  mapper->Delete();

  vtkRenderer* renderer = vtkRenderer::New();
  renderer->AddActor(actor);
  actor->Delete();

  vtkRenderWindow* window = vtkRenderWindow::New();
  window->OffScreenRenderingOn();
  window->AddRenderer(renderer);
  renderer->Delete();
  window->Render();

  window->Delete();

  return 0;
}
