#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define __MAIN__
#include "common.h"
#include "array.h"

bool test_type(void) {
    Array x = Array_new(undefArray);
    ArrayType atype = int32Array;
    ArrayType btype;

    printf("test_type: set array type to int32 and check if it really happens\n");
    Array_setType(x, atype);
    btype = Array_getType(x);
    if (btype != atype) {
	fprintf(stderr, "   Error: getType (%s) != setType(%s)\n", arrayTypeStrings[btype], arrayTypeStrings[atype]);
	return false;
    }
    return true;
}

int test_alloc(void) {
    Array x = Array_new(int32Array);
    int n = 10;

    printf("test_alloc: allocate an int32 array with %d elements\n", n);
    Array_allocate(x, n);
    if (Array_errno(x)) {
	fprintf(stderr, "   Problem: array was not allocated (malloc failed)\n");
	return true; // still the test is okay
    }
    if (Array_length(x) != n) {
	fprintf(stderr, "   Error: length (%ld) != intended length of allocation (%d)\n", Array_length(x), n);
	return false;
    }
    Array_free(x);
    return true;
}

int test_alloc_dims(void) {
    Array x = Array_new(doubleArray);
    int ndims = 5;
    int dims[5] = { 16, 16, 2, 2, 2};
    int length = 2048;

    printf("test_alloc_dims: allocate double array with %dx%dx%dx%dx%d dimensions\n", 
            dims[0], dims[1], dims[2], dims[3], dims[4]);
    Array_allocate_dims(x, ndims, dims);
    if (Array_errno(x)) {
	fprintf(stderr, "   Problem: array was not allocated (malloc failed)\n");
	return true; // still the test is okay
    }
    if (Array_length(x) != length) {
	fprintf(stderr, "   Error: length (%ld) != intended length of allocation (%d)\n", Array_length(x), length);
	return false;
    }
    Array_free(x);
    return true;
}
int test_data1(void) {
    Array x = Array_new(int32Array);
    int32_t y[10] = {0,1,2,3,4,5,6,7,8,9};
    int32_t *p;
    int n = 10, i;

    printf("test_data1: create an int32 array with %d elements\n", n);
    Array_allocate(x, n);
    if (Array_errno(x)) {
	fprintf(stderr, "   Problem: array was not allocated (malloc failed)\n");
	return true; // still the test is okay
    }
    
    p = Array_getDataPointer(x);
    for (i = 0; i < n; i++) p[i] = y[i];

    Array_free(x);
    return true;
}

int test_indgen(void) {
    int32_t y[10] = {0,1,2,3,4,5,6,7,8,9};
    int32_t *p;
    int n = 10, i;
    Array x;

    printf("test_indgen: create an int32 array [0..%d]\n", n-1);
    x = Array_indgen(0,n-1,1);

    if (Array_length(x) != n) {
	fprintf(stderr, "   Error: length (%ld) != intended length of allocation (%d)\n", Array_length(x), n);
        Array_free(x);
	return false;
    }
    if (Array_getType(x) != int32Array) {
	fprintf(stderr, "   Error: Type of array (%s) is not int32Array\n", arrayTypeStrings[Array_getType(x)]);
        Array_free(x);
	return false;
    }
    p = Array_getDataPointer(x);
    for (i=0; i<n; i++) {
        if ( p[i] != y[i] ) {
            fprintf(stderr, "   Error: indgen[%d]=%d is not the expected %d\n", i, p[i], y[i]);
            Array_free(x);
            return false;
        }
    }

    Array_free(x);
    return true;
}


int main( int argc, char *argv[]) {
    bool retval = true;
    retval &= test_type();
    retval &= test_alloc();
    retval &= test_alloc_dims();
    retval &= test_data1();
    retval &= test_indgen();
    return (retval != true);
}

