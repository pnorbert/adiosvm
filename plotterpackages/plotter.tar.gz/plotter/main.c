/* Make x-y plots or print two column ascii from 1D variables stored in NetCDF/HDF5/ADIOS files. 
 *
 * The X-axis is one of the variables stored in a file.
 * The Y-axis is another or all variable(s) in the same or another file
 *
 * Copyright Oak Ridge National Laboratory 2009
 * Authors: Norbert Podhorszki, pnorbert@ornl.gov
**/

#ifndef _GNU_SOURCE
#   define _GNU_SOURCE
#endif

#define __MAIN__
#include "common.h"
#include "array.h"
#include "dirutil.h"
#include "graceplot.h"
#include "reader.h"
#include "minmax.h"
#include "timer.h"

#ifdef VTK
#   include "vtk-graph.h"
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <getopt.h>
#include <errno.h>
#include <limits.h>   // LONG_MAX
#include <math.h>     // NAN
#include <libgen.h>   // basename
#include <regex.h>    // regular expression matching
#include <fnmatch.h>  // shell pattern matching

// global variables (for main.c only)
#define MAX_MASKS 10
// Values from the arguments or defaults
char *outpath;              // output files' starting path (can be extended with subdirs, names, indexes)
char *xvar;                 // name of x variable 
char *tvar;                 // name of time variable 
char *varmask[MAX_MASKS];   // can have many -var masks (either shell patterns or extended regular expressions)
int  nmasks;                // number of masks specified
char *xfile;                // file containing x variable
char *tfile;                // file containing t variable
char *vfile;                // file containing variable (values) to plot
char *minmaxfile;           // file containing min/max values for variables (written by plotter)
char *start;                // dimension spec starting points 
char *count;                // dimension spec counts
char *xstart;               // dimension spec starting points 
char *xcount;               // dimension spec counts
char *nameattr;             // the attribute which defines the display name instead of the var's name
char *title;                // Title of the (single) plot
char *subtitle;             // subtitle of the (single) plot
char *xaxisname;            // force to plot this as X axis string
FileType xfiletype;
FileType tfiletype;
FileType vfiletype;
double xmin, xmax, vmin, vmax;
int  outidxWidth;           // how many characters should the index in output name occupy (padded with 0)
int  sizeX, sizeY;          // output image size
int  fgColor[3];            // output image foreground color rgb array (0..255 values)
int  bgColor[3];            // output image background color rgb array (0..255 values)
int  timeFix;               // time value to add to file names, given as argument 
                            //   used only when there is no time iteration 

// Flags from arguments or defaults
bool output_ascii;
bool output_xml;
bool output_separate_dirs;
bool output_agr;
bool use_global_minmax;    // plot with calculate global minmax values for each y variable
bool skip_undef;           // skip a plot if all values are undef
bool use_regexp;           // use varmasks as regular expressions
bool list_only;            // list the variables and exit
bool multiplot;            // Make only one image that draws all variables (and all times!!!)
bool multiplot_time;       // Make one image per variable containing all timesteps
bool hide_axes;            // Do not plot the axes (2D only yet but maybe will be used for 1D)

// Variables related to 2D graphics
char *yvar;                 // name of y variable (2D plots)
char *yfile;                // file containing y variable for 2D structured grid plots
char *ystart;               // dimension spec starting points 
char *ycount;               // dimension spec counts
char *yaxisname;            // force to plot this as Y axis string
double ymin, ymax;
FileType yfiletype;
bool plot_in_2D;           // true if 2D graphics is requested for 2D arrays
#ifdef VTK
char *colormap;            // set if given as argument
vtk_options vtkopts = VTK_OPTIONS_NEW;      
bool do_trianglemesh;      // the data is on a triangle mesh, x should be the vertices and y should be the triangles
bool do_rectilinear;       // plot a rectilinear grid, x and y should be 1D arrays of coordinates
bool use_polar_coordinates;// x/y is given as radius/angle or angle/radius for a polar plot
bool do_squareplots;       // scale x or y axis in 2D to get a square plot
bool transpose;            // use transpose of v in 2D plots
#endif

// other global variables
char *prgname; /* argv[0] */
long timeFrom, timeSteps, timeDimidx, timeStepping;
int  xistart[MAX_DIMS], xicount[MAX_DIMS];
int  yistart[MAX_DIMS], yicount[MAX_DIMS];
int  tistart[MAX_DIMS], ticount[MAX_DIMS]; // t var is read in full always
int  istart[MAX_DIMS], icount[MAX_DIMS];
regex_t varregex[MAX_MASKS]; // compiled regular expressions of varmask
int  ascii_width; // how many values to print in one row (only for -p)
int  n1Dvars = 0; // number of variables actually plotted in 1D; used for multiplot
struct timeval tp;

// prototypes
static int print_data_1D(char *outnamespec, char *xname, char* vname, Array x, Array v);
static int print_data_2D(char *outnamespec, char *xname, char* yname, char* vname, Array x, Array y, Array v);
static void parseDimSpec(char *str, int *dims, bool allow_time, long *tDimidx, long *tValue, long *tStepping);
static void parseRGB(char *str, int rgb[3]);

// option processing variables
enum opts {
    OPT_INPUT_X 
   ,OPT_INPUT_T 
   ,OPT_MINMAXFILE 
   ,OPT_TYPE_X 
   ,OPT_TYPE_T 
   ,OPT_TYPE_V 
   ,OPT_OUTPUT_XML 
   ,OPT_OUTPUT_AGR 
   ,OPT_XSTART
   ,OPT_XCOUNT
   ,OPT_SEPARATE_DIRS 
   ,OPT_USE_GLOBALMINMAX
   ,OPT_XMIN 
   ,OPT_XMAX 
   ,OPT_VMIN 
   ,OPT_VMAX 
   ,OPT_OUTPUT_INDEX_WIDTH
   ,OPT_SKIP_UNDEF
   ,OPT_USE_REGEXP
   ,OPT_PRINT_PROVENANCE
   ,OPT_IMGSIZE
   ,OPT_FOREGROUND
   ,OPT_BACKGROUND
   ,OPT_NAMEATTR
   ,OPT_TIMEFIX
   ,OPT_MULTIPLOT
   ,OPT_MULTIPLOT_TIME
   ,OPT_TITLE
   ,OPT_SUBTITLE
   ,OPT_XAXISNAME
   ,OPT_HIDE_AXES
#ifdef VTK
   ,OPT_INPUT_Y 
   ,OPT_TYPE_Y 
   ,OPT_YSTART
   ,OPT_YCOUNT
   ,OPT_YMIN 
   ,OPT_YMAX 
   ,OPT_2D_COLORMAP
   ,OPT_2D_CONTOUR
   ,OPT_POLAR
   ,OPT_MAKESQUAREPLOT
   ,OPT_TRIANGLEMESH
   ,OPT_RECTILINEAR
   ,OPT_BALANCE_COLORMAP
   ,OPT_ZONAL
   ,OPT_TRANSPOSE
   ,OPT_YAXISNAME
#endif
};

int opt;

struct option options[] = {
    {"help",                 no_argument,          NULL,    'h'},
    {"debug",                no_argument,          NULL,    'd'},
    {"output",               required_argument,    NULL,    'o'},
    {"output-ascii",         no_argument,          NULL,    'p'},
    {"output-xml",           no_argument,          &opt,    OPT_OUTPUT_XML},
    {"ls",                   no_argument,          NULL,    'l'},
    {"print",                optional_argument,    NULL,    'p'},
    {"var",                  required_argument,    NULL,    'v'},
    {"xvar",                 required_argument,    NULL,    'x'},
    {"tvar",                 required_argument,    NULL,    't'},
    {"file",                 required_argument,    NULL,    'f'},
    {"xfile",                required_argument,    &opt,    OPT_INPUT_X},
    {"tfile",                required_argument,    &opt,    OPT_INPUT_T},
    {"filetype",             required_argument,    &opt,    OPT_TYPE_V},
    {"xfiletype",            required_argument,    &opt,    OPT_TYPE_X},
    {"tfiletype",            required_argument,    &opt,    OPT_TYPE_T},
    {"start",                required_argument,    NULL,    's'}, 
    {"count",                required_argument,    NULL,    'c'}, 
    {"xstart",               required_argument,    &opt,    OPT_XSTART}, 
    {"xcount",               required_argument,    &opt,    OPT_XCOUNT}, 
    {"minmaxfile",           required_argument,    &opt,    OPT_MINMAXFILE},    
    {"output-separate-dirs", no_argument,          &opt,    OPT_SEPARATE_DIRS},
    {"agr",                  no_argument,          &opt,    OPT_OUTPUT_AGR},
    {"use-global-minmax",    no_argument,          &opt,    OPT_USE_GLOBALMINMAX},
    {"min",                  required_argument,    &opt,    OPT_VMIN},
    {"max",                  required_argument,    &opt,    OPT_VMAX},
    {"xmin",                 required_argument,    &opt,    OPT_XMIN},
    {"xmax",                 required_argument,    &opt,    OPT_XMAX},
    {"output-index-width",   required_argument,    &opt,    OPT_OUTPUT_INDEX_WIDTH},
    {"skip-undef",           no_argument,          &opt,    OPT_SKIP_UNDEF},
    {"regexp",               no_argument,          &opt,    OPT_USE_REGEXP},
    {"print-provenance",     no_argument,          &opt,    OPT_PRINT_PROVENANCE},
    {"imgsize",              required_argument,    &opt,    OPT_IMGSIZE},
    {"fg",                   required_argument,    &opt,    OPT_FOREGROUND},
    {"bg",                   required_argument,    &opt,    OPT_BACKGROUND},
    {"nameattr",             required_argument,    &opt,    OPT_NAMEATTR},
    {"tfix",                 required_argument,    &opt,    OPT_TIMEFIX},
    {"multiplot",            no_argument,          &opt,    OPT_MULTIPLOT},
    {"multiplot-time",       no_argument,          &opt,    OPT_MULTIPLOT_TIME},
    {"title",                required_argument,    &opt,    OPT_TITLE},
    {"subtitle",             required_argument,    &opt,    OPT_SUBTITLE},
    {"hide-axes",            no_argument,          &opt,    OPT_HIDE_AXES},
#ifdef VTK
    {"yvar",                 required_argument,    NULL,    'y'},
    {"yfile",                required_argument,    &opt,    OPT_INPUT_Y},
    {"yfiletype",            required_argument,    &opt,    OPT_TYPE_Y},
    {"ystart",               required_argument,    &opt,    OPT_YSTART}, 
    {"ycount",               required_argument,    &opt,    OPT_YCOUNT}, 
    {"ymin",                 required_argument,    &opt,    OPT_YMIN},
    {"ymax",                 required_argument,    &opt,    OPT_YMAX},
    {"colormap",             required_argument,    &opt,    OPT_2D_COLORMAP},
    {"contour",              optional_argument,    &opt,    OPT_2D_CONTOUR},
    {"polar",                optional_argument,    &opt,    OPT_POLAR},
    {"square",               no_argument,          &opt,    OPT_MAKESQUAREPLOT},
    {"triangle-mesh",        no_argument,          &opt,    OPT_TRIANGLEMESH},
    {"rectilinear",          no_argument,          &opt,    OPT_RECTILINEAR},
    {"balance-colormap",     no_argument,          &opt,    OPT_BALANCE_COLORMAP},
    {"zonal",                no_argument,          &opt,    OPT_ZONAL},
    {"transpose",            no_argument,          &opt,    OPT_TRANSPOSE},
    {"xname",                required_argument,    &opt,    OPT_XAXISNAME},
    {"yname",                required_argument,    &opt,    OPT_YAXISNAME},
#endif
    {NULL,                   0,                    NULL,    0}
};


static const char *optstring = "-hdo:v:x:y:t:f:s:c:lp::";

// help function
void display_help() {
   //printf( "Usage: %s  \n", prgname);
   printf(
        "\n1. Plot 1 variable against 1 other variable. \n"
        "   Read them from same or different files\n"
        "\n"
        "plotter  \n"
        "     -var | -v <mask>        # REQUIRED: name of variable to use for values.\n"
        "                                 You can specify more than one -var masks in a command-line.\n"
        "                                 A mask can be a shell pattern (that you use with 'ls' e.g.)\n"
        "                                 If you want extended regular expressions, use option -regexp.\n"
        "     -file | -f <path>       # REQUIRED: file containing variables (-var)\n"
        "     -filetype <type>        # optional, one of 'netcdf, hdf5, adios'\n"
        "     -start | -s \"spec\"      # optional, starting indexes for each dimension (default \"0\") \n"
        "                                 'tN' in one dimension = plotter loops over that dimension and \n"
        "                                 produces as many images as the count for that dimension is given.\n"
        "                                 'tN:S' : loop from N, count times but with a stepping of S.\n"
        "     -count | -c \"spec\"      # optional, counting for each dimension (default \"-1\")  \n"
        "                                 -1 denotes 'until end' of array\n"
        "\n"
        "     -xvar <name>            # optional: name of variable to use for X axis values \n"
        "                                 if not given 0..<length of var>-1 is used\n"
#ifdef VTK
        "                                 For 2D plots, it is used as X coordinates.\n"
#endif
        "     -xfile <path>           # optional, file containing xvar, default = -file\n"
        "     -xfiletype <type>       # optional, one of 'netcdf, hdf5, adios'\n"
        "     -xstart \"spec\"          # optional, starting indexes for each dimension (default \"0\")\n"
        "     -xcount \"spec\"          # optional, counting for each dimension (default \"-1\")\n"
#ifdef VTK
        "\n"
        "     -yvar <name>            # optional for 2D plots: name of variable to use as Y coordinates. \n"
        "     -yfile | -f <path>      # optional: file containing yvar, default = -xfile\n"
        "     -yfiletype <type>       # optional, one of 'netcdf, hdf5, adios'\n"
        "     -ystart | -s \"spec\"     # optional, starting indexes for each dimension (default \"0\")\n"
        "     -ycount | -c \"spec\"     # optional, counting for each dimension (default \"-1\")\n"
#endif
        "\n"
        "   If file types are missing, automatic check will be done\n"
        "\n"
        "   Examples for slicing:\n"
        "   -s \"0,0,0\"    -c \"0,99,0\":  read 100 elements (of the 2nd dimension) to plot.\n"
        "   -s \"0,0,0\"    -c \"0,-1,0\":  read the whole 2nd dimension to plot.\n"
        "   -s \"t0,0,0\"   -c \"10,99,0\": read 100 elements (of the 2nd dimension) to plot,\n"
        "      11 times for the first dimension indices 0..10 and produce 11 plots.\n"
        "   -s \"t0,0,0\"   -c \"-1,99,0\": create all timesteps\n"
        "   -s \"t0:2,0,0\" -c \"30,99,0\": NOT IMPLEMENTED! create 30 timesteps for 0,2,4,...58\n"

        "\n"
        "\n2. like 1. just output as ascii into a file\n"
        "    -print | -p        # valueX valueY    per line (no : in it!) (same as -p0)\n" 
        "    -p<cols>           # valueX_1:        valueY_1        ... valueY_<cols> \n"
        "                       # valueX_<cols+1>: valueY_<cols+1> ... valueY_<2*cols> \n"
        "                       # ... \n"
        "    --output-xml       # <point>\n"
        "                           <X>valueX</X>\n"
        "                           <Y>valueY</Y>\n"
        "                         </point>\n"
        "\n"
        "\nOutput identification:\n"
        "   one image:    -output | -o <path>      # path to a file name, or a dir, so\n"
        "                                          # that filename=<path>/yvar.time.png\n"
        "   timed images:  -output | -o <path>     # for each yvar and time,\n"
        "                                          # imgpath = <path>/yvar.time.png\n"
        "                 --output-separate-dirs   # for each yvar and time,\n" 
        "                                          # imgpath = <path>/yvar/yvar.time.png\n"
        "                                          # Subdirectories will be created\n"
        "\n"
        "\nOptional arguments:\n"
        "     --agr                       # output AGR file too, not just PNG\n"
        "     --use-global-minmax         # use minmax file to determine global Y scale\n"
        "     --minmaxfile <path>         # the minmax file (read if use-global-minmax,\n"
        "                                 #   write otherwise)\n"
        "     -xmin <value>               # use value as min for the X scale\n"
        "     -xmax <value>               # use value as max for the X scale\n"
#ifdef VTK
        "     -xname <string>             # print this as X axis name (instead of xvar or x)\n"
        "     -ymin <value>               # use value as min for the Y scale\n"
        "     -ymax <value>               # use value as max for the Y scale\n"
        "     -yname <string>             # print this as Y axis name (instead of yvar or y)\n"
#endif
        "     -t | -tvar <name>           # an array containing file output indexes\n"
        "                                 #   indexes run tN,...,tN+count-1 if t is defined in -start\n"
        "                                 #   indexes run 0,1,... otherwise\n"
        "     -tfile <path>               # file containing t variable, default = -file\n"
        "     -tfiletype <type>           # type of tfile\n"
        "     -tfix <num>                 # add a time output index <num> to the files when no\n"
        "                                 #    iterations are there (single plot per variable).\n"
        "                                 #    Used only if -start has no t def and no -t used.\n"
        "     -output-index-width <val>   # default: 4;   in file names,\n"
        "                                 #     print time as %%.<val>d \n"
        "     -skip-undef                 # if a variable at a time is undefined \n"
        "                                 #     (values are undef) then skip plot \n"
        "     -regexp                     # treat var masks as extended regular expressions\n"
        "     -nameattr                   # attribute of variable in file that defines what name\n"
        "                                 #   to display instead of the variable path\n"
        "     -multiplot-time             # plot all timestep of a variable in one graph\n"
        "                                 #   i.e. one image per variable is generated\n"
        "                                 #   1D only option\n"
        "     -multiplot                  # plot all variables in one graph\n"
        "                                 #   i.e. one image is created only\n"
        "                                 #   Note: No looping over time is allowed!\n"
        "                                 #   1D only option\n"
#ifdef VTK
        "\n"
        "\n2D graphics options:\n"
        "    If the selection results in a 2D array, you can use VTK to make 2D graphs instead\n"
        "    of the x-y plots.\n"
        "\n"
        "    --colormap <cmapname>        # select a colormap instead of the default blue-red:\n"
        "                                 # RedBlue, BlueRed, Gray, XGC, XGCLog, HotDesaturated\n"
        "    --contour[= #_of_contours]   # make a contour plot from the 2D array\n"
        "    --triangle-mesh              # plot an unstructured triangle mesh.\n"
        "                                 # -v should be the values array (1D array of N values)\n"
        "                                 # -x should be the vertices list (Nx2 or Nx3 array),\n"
        "                                 # -y should be the triangle list (Mx3 array)\n"
        "    --rectilinear                # plot an array in a rectilinear grid.\n"
        "                                 # -v should be the values array (NxM array)\n"
        "                                 # -x should be the x coords (N array),\n"
        "                                 # -y should be the y coords (M array)\n"
        "    --polar[=[x|y]]              # use x and y as radius/angle for a polar plot\n"
        "                                 #   use -polar=y if v is ordered as angles x radius\n"
        "    --square                     # magnify x or y to get a square plot of a 2D array\n"
        "    --balance-colormap           # change min/max to the same absolute value to have 0.0\n"
        "                                 #   as the center of the colormap. Works only if the difference\n"
        "                                 #   between absolute value of min and max is < 50%% of the\n"
        "                                 #   total distance between min and max.\n"
        "     -min <value>                # use value as minimum for the colormap\n"
        "     -max <value>                # use value as maximum for the colormap\n"
        "     -zonal                      # plot 2D array with cell centered data (not smooth gradient)\n"
        "                                 #   only for plain 2D array plots\n"
        "     -transpose                  # transpose 2D array before plotting.\n"
        "                                 #   X axis becomes the horizontal axis this way\n"
        "     -hide-axes                  # do not draw axes in plots where it would be by default\n"
#endif        
        "\n"
        "\nImage options\n"
        "     -imgtype <type>             # png, jpg\n"
        "     -imgsize <X> <Y>            # size of image X x Y pixels\n"
        "     -fg \"r,g,b\"                 # foreground color in RGB, 0..255 values\n"
        "                                 #  used for 1D plots as drawing color; \n"
#ifdef VTK
        "                                 #  in 2D, used for ticks and labels only\n"
#endif
        "     -bg \"r,g,b\"                 # background color in RGB, 0..255 values\n"

        "\n"
        "Secret options for the workflow processing\n"
        "     --print-provenance          # print a provenance line for each image generated\n"

        "\nHelp options\n"
        "  --ls    | -l  Just list the variables and their dimensions in a file matching given masks\n"
        "  --help  | -h  Print this help.\n"
        "  --debug | -d  Print log about what this program is doing. Use multiple -d to increase debug level.\n"
        "All options can be defined with - and --\n"
        );
}

void init_globals(void) {
    int i;
    // variables for arguments
    outpath              = NULL;
    xvar                 = NULL;
    xaxisname            = NULL;
    tvar                 = NULL;
    for (i=0; i<MAX_MASKS; i++)
        varmask[i]       = NULL;
    nmasks               = 0;
    xfile                = NULL;
    tfile                = NULL;
    vfile                = NULL;
    xfiletype            = undef_file;
    tfiletype            = undef_file;
    vfiletype            = undef_file;
    minmaxfile           = NULL;
    start                = NULL;
    count                = NULL;
    xstart               = NULL;
    xcount               = NULL;
    nameattr             = NULL;
    title                = NULL;
    subtitle             = NULL;
    verbose              = 0;
    list_only            = false;
    output_ascii         = false;
    ascii_width          = 0;    // by default when printing ascii, print "X Y", not X: Y1 Y2...
    output_xml           = false;
    output_separate_dirs = false;
    output_agr           = false;
    use_global_minmax    = false;
    skip_undef           = false;
    use_regexp           = false;
    print_provenance     = false;
    multiplot            = false;
    multiplot_time       = false;
    hide_axes            = false;
    xmin                 = NAN;
    xmax                 = NAN;
    vmin                 = NAN;
    vmax                 = NAN;
    //other
    timeFrom             = 0;
    timeSteps            = 0;
    timeStepping         = 1;
    timeDimidx           = -1;
    timeFix              = -1;
    outidxWidth          = 4;
    sizeX                = 0;
    sizeY                = 0;
    fgColor[0]           = 0;
    fgColor[1]           = 0;
    fgColor[2]           = 0;   // default is black foreground
    bgColor[0]           = 255;
    bgColor[1]           = 255;
    bgColor[2]           = 255; // default is white background
    // set defaults
    for (i=0; i<MAX_DIMS; i++) {
        istart[i]  = 0;
        icount[i]  = -1;  // read full var by default
        xistart[i] = 0;
        xicount[i] = -1;  // read full x var by default
        tistart[i] = 0;
        ticount[i] = -1;  // read full t var (cannot be changed by arguments)
    }

    // 2D  (variables are initialized even for not #ifdef VTK case)
    plot_in_2D          = false;  // in plotter
    yvar                = NULL;
    yaxisname           = NULL;
    yfile               = NULL;
    yfiletype           = undef_file;
    ystart              = NULL;
    ycount              = NULL;
    ymin                = NAN;
    ymax                = NAN;
    for (i=0; i<MAX_DIMS; i++) {
        yistart[i] = 0;
        yicount[i] = -1;  // read full y var by default
    }
#ifdef VTK
    plot_in_2D            = true;  // in plotter2D
    colormap              = NULL;
    do_trianglemesh       = false;
    do_rectilinear        = false;
    use_polar_coordinates = false;
    do_squareplots        = false;
    transpose             = false;
    vtk_init();
#endif
}


bool isDefined(char *var, char* name, bool printerror) {
    /* Check if required variable is defined */
    if (var == NULL) {
        if (printerror)
            fprintf(stderr, "Error: %s is not defined!\n", name);
        return false;
     }
    return true;
}

/** Check for missing args and contradictions.
  */
bool checkArgs(void) {
    bool retval = true;
    int  i, errcode;
    char buf[256];

    // xvar == NULL means simply 1..n-1
    //retval &= isDefined(xvar, "xvar", true); 

    // we need a file 
    retval &= isDefined(vfile, "file", true);  

    // we need start and count 
    //retval &= isDefined(ystart, "ystart", true);  
    //retval &= isDefined(ycount, "ycount", true);  

    // all plots or one defined with -var
    if (!list_only && nmasks == 0) {
        fprintf(stderr, "Error: at least one -var <mask> should be specified\n");
        retval = false;
    }
        
    // output file or dir must be specified
    if (!list_only && !output_ascii)
        retval &= isDefined(outpath, "output", true);

    // separate-dirs and outpath is not a directory
    if (output_separate_dirs && !is_dir(outpath)) {
        fprintf(stderr, "Error: --output-separate-dirs was set, but outpath is not a directory: %s\n", outpath);
        retval = false;
    }

    // check on minmax options
    if (use_global_minmax && minmaxfile == NULL) {
        fprintf(stderr, "Error: --use-global-minmax was set, but no minmaxfile is specified with --minmaxfile\n");
        retval = false;
    }

    // AGR can be printed with xmgrace only, so cannot be ascii
    if (output_ascii && output_agr) {
        fprintf(stderr, "Error: --agr can be used only when making images, not ascii output\n");
        retval = false;
    }

    // xstart and xcount has meaning only if xvar is defined
    if (xvar == NULL && (xstart != NULL || xcount != NULL)) {
        fprintf(stderr, "Error:  xstart and xcount has meaning only if xvar is defined\n");
        retval = false;
    }

    // tvar is allowed only if there is 't' in the -start specification
    if (tvar != NULL && (start == NULL || strchr(start, 't') == NULL)) {
        fprintf(stderr, "Error:  tvar is allowed only if there is 't' in the -start specification\n");
        retval = false;
    }

    // process the regular expressions
    if (use_regexp) {
        for (i=0; i<nmasks; i++) {
        
            //errcode = regcomp( &(varregex[i]), varmask[i], REG_EXTENDED | REG_NOSUB);
            errcode = regcomp( &(varregex[i]), varmask[i], REG_EXTENDED);
            if (errcode) {
                regerror(errcode, &(varregex[i]), buf, 256);
                fprintf(stderr, "Error: var %s is an invalid extended regular expression: %s\n", varmask[i], buf);
                retval = false;
            }
        }
    }

#ifdef VTK
    // ystart and ycount has meaning only if yvar is defined
    if (yvar == NULL && (ystart != NULL || ycount != NULL)) {
        fprintf(stderr, "Error:  ystart and ycount has meaning only if yvar is defined\n");
        retval = false;
    }
    // y is useful only if x is also specified
    if (yvar != NULL && xvar == NULL) {
        fprintf(stderr, "Error:  yvar can be used only if xvar is also used for 2D plots\n");
        retval = false;
    }
    if (do_trianglemesh && do_rectilinear) {
        fprintf(stderr, "Error: Use only one of --triangle-mesh and --rectilinear\n");
        retval = false;
    }
    if (do_trianglemesh && (yvar == NULL || xvar == NULL)) {
        fprintf(stderr, "Error: With --triangle-mesh, specify the vertices with -x and the triangle connection list with -y\n");
        retval = false;
    }
    if (do_rectilinear && (yvar == NULL || xvar == NULL)) {
        fprintf(stderr, "Error: With --rectilinear, specify the coordinates with -x and -y\n");
        retval = false;
    }
#endif

    // check the multi-plot issues
    if (multiplot && multiplot_time) {
        fprintf(stderr, "Error: Cannot use --multiplot and --multiplot-time! together\n");
        retval = false;
    }

    if (multiplot && start != NULL && strchr(start,'t') != NULL) {
        fprintf(stderr, "Error: Cannot use --multiplot and loop over time for one variable at the same time\n");
        fprintf(stderr, "Use --multiplot-time to plot several timesteps of one variable in one image\n");
        retval = false;
    }

#ifndef XMGRACE
    if (!list_only && !output_ascii && !plot_in_2D) {
        fprintf(stderr, "Error: plotter is not compiled with xmgrace, so you must use -p or --output-xml to print text.\n");
        retval = false;
    }
#endif

    return retval;
}

/** Set default values for those variables that are not set and need not be set with an argument 
  */
static void setDefaultsAfterArgs(void) {
    if (xfile == NULL) {
            xfile = vfile;
        xfiletype = vfiletype;
    }
    if (tfile == NULL) {
            tfile = vfile;
        tfiletype = vfiletype;
    }
#ifdef XMGRACE
    if (sizeY > 0) grace_setImageSize(sizeX, sizeY);
    grace_setForeground(fgColor);
    grace_setBackground(bgColor);
#endif
#ifdef VTK
    if (yfile == NULL) {
            yfile = xfile;
        vfiletype = xfiletype;
    }
    if (sizeY > 0) vtk_setImageSize(sizeX, sizeY);
    vtk_setForeground(fgColor);
    vtk_setBackground(bgColor);
#endif
}

/** Set the start[] and count[] arrays to read variables.
  * start:  "[t][-]n[,...]"; 't' in a dimension denotes the time dimension
  *                          only one t is allowed
  * count:  "[-]n[,...]"; -1 denotes 'until end'
  */
static void processDimSpecs(void) {
    //int i;

    // process var 
    if (start != NULL) parseDimSpec(start, istart, true, &timeDimidx, &timeFrom, &timeStepping); // parse start into istart int array
    //printf("  start = { ");
    //for (i=0; i<MAX_DIMS;i++) printf("%d ", istart[i]);
    //printf("}\n");
    //printf("  timeDimidx = %ld\n", timeDimidx);

    if (count != NULL) parseDimSpec(count, icount, false, NULL, NULL, NULL);
    if (timeDimidx > -1) {
        // get end time index from count
        timeFrom = istart[ timeDimidx ];
        timeSteps = icount[ timeDimidx ];
        //icount[ timeDimidx ] = 1;  // will read only one dimension at a time (should be set before reading a var)
    }
    //printf("  count = { ");
    //for (i=0; i<MAX_DIMS;i++) printf("%d ", icount[i]);
    //printf("}\n");

    // process x
    if (xstart != NULL) parseDimSpec(xstart, xistart, false, NULL, NULL, NULL);
    if (xcount != NULL) parseDimSpec(xcount, xicount, false, NULL, NULL, NULL);

#ifdef VTK
    // process y
    if (ystart != NULL) parseDimSpec(ystart, yistart, false, NULL, NULL, NULL);
    if (ycount != NULL) parseDimSpec(ycount, yicount, false, NULL, NULL, NULL);
#endif
}

#define PRINT_DIMS(str, v) printf("  %s = { ", str); \
    for (i=0; i<MAX_DIMS;i++) printf("%d ", v[i]);    \
    printf("}\n");

static void printSettings(void) {
    int i;
    printf("Settings:\n");
    printf("  var(s) %d: ", nmasks);
    for (i=0; i<nmasks; i++)
        printf("%s ", varmask[i]);
    printf("\n");
    if (xvar != NULL) printf("  x var: %s\n", xvar);
    if (yvar != NULL) printf("  y var: %s\n", yvar);
    printf("  file  : %s  type=%s\n", vfile, fileTypeStrings[vfiletype]);
    if (xvar != NULL) printf("  x file: %s  type=%s\n", xfile, fileTypeStrings[xfiletype]);
    if (yvar != NULL) printf("  y file: %s  type=%s\n", yfile, fileTypeStrings[yfiletype]);
    printf("  output: %s\n", outpath);
    if (!isnan(vmin)) printf("  min  = %lf\n", vmin);
    if (!isnan(vmax)) printf("  max  = %lf\n", vmax);
    if (!isnan(xmin)) printf("  xmin = %lf\n", xmin);
    if (!isnan(xmax)) printf("  xmax = %lf\n", xmax);
    if (!isnan(ymin)) printf("  ymin = %lf\n", ymin);
    if (!isnan(ymax)) printf("  ymax = %lf\n", ymax);
    if (xaxisname != NULL) printf("  x axis string: %s\n", xaxisname);
    if (yaxisname != NULL) printf("  y axis string: %s\n", yaxisname);

    printf("\nDimension specification:\n");
    if (timeDimidx > -1) printf("  time: idx=%ld, %ld steps from %ld with stepping of %ld\n", 
        timeDimidx, timeSteps, timeFrom, timeStepping);
    PRINT_DIMS("start", istart)
    PRINT_DIMS("count", icount)
    if (xstart != NULL || xcount != NULL) {
        PRINT_DIMS("xstart", xistart)
        PRINT_DIMS("xcount", xicount)
    }
    if (ystart != NULL || ycount != NULL) {
        PRINT_DIMS("ystart", yistart)
        PRINT_DIMS("ycount", yicount)
    }

    printf("\nOptions:\n");
    if (use_global_minmax)      printf("  Use minmax file to plot global minmax images\n");
    if (minmaxfile)             printf("  Minmax file: %s\n", minmaxfile);
                                printf("  output index width = %d\n", outidxWidth);
    if (output_ascii)           printf("  Output text instead of image\n");
    if (output_xml)             printf("  Output text in XML format\n");
    if (output_separate_dirs)   printf("  Output in separate dirs under %s\n", outpath);
    if (output_agr)             printf("  Output AGR file besides the image\n");
    if (skip_undef)             printf("  Skip plot if a variable is undefined\n");
    if (sizeY > 0)              printf("  Image size set to %dx%d\n", sizeX, sizeY);
    if (multiplot)              printf("  Plot all variables in one graph\n");
    if (multiplot_time)         printf("  Plot all timesteps in one graph\n");
    if (title != NULL)          printf("  Plot title: %s\n", title);
    if (subtitle != NULL)       printf("  Plot subtitle: %s\n", subtitle);
#ifdef VTK
    if (plot_in_2D)             printf("\n2D Options:\n");
    if (colormap)               printf("  Colormap %s\n", colormap); 
    if (vtkopts.do_contour)     printf("  Make a contour plot\n");
    if (do_trianglemesh)        printf("  Plot over a triangle mesh\n");
    if (do_rectilinear)         printf("  Plot over a rectilinear grid\n");
    if (do_squareplots)         printf("  Make plots square\n");
    if (transpose)              printf("  Transpose 2D array before plotting\n");
    if (hide_axes)              printf("  Hide axes\n");
    if (use_polar_coordinates) 
    {
                                printf("  Use polar coordinates. ");
       if (vtkopts.radius_is_first_dim) 
                                printf("X is radius, Y is angle data\n");
       else
                                printf("X is angle, Y is radius data\n");
    }
    vtk_printSettings();
#endif
        
}

void determineMinMax( char *varname, Array a, double *minval, double *maxval) {
    double gmin, gmax;

    if (use_global_minmax) {
        // read the global min/max from file
        minmax_get(varname, Array_get_undef_value(a), &gmin, &gmax);
    }
    
    // determine the min value
    if (!isnan(vmin)) 
        *minval = vmin;        // given as argument
    else if (use_global_minmax) 
        *minval = gmin;        // got value from minmax file
    else {
        *minval = Array_min(a); // calculate from the array
    }
   
    // determine the max value
    if (!isnan(vmax)) 
        *maxval = vmax;        // given as argument
    else if (use_global_minmax) 
        *maxval = gmax;        // got value from minmax file
    else {
        *maxval = Array_max(a); // calculate from the array
    }

}

#ifdef VTK
/** 2D plot a 2D array with vtk.
  * Input v is expected to be a 2D array except for triangle meshes where v must be a 1D array.
  * min_val and max_val are the min-max for the colormap of the plots
  */
int plotVar2D( char *title, Array v, char* imagefilename, double min_v, double max_v,
               Array x, char *xname, double min_x, double max_x,
               Array y, char *yname, double min_y, double max_y) 
{
    int i, retval=0;
    // temp vars for error checking
    int ndims_v = 0, ndims_x = 0, ndims_y = 0;
    int dimv[2] = {0,0};
    int dimx[2] = {0,0};
    int dimy[2] = {0,0};

    // determine dimensions of all arrays
    ndims_v = Array_getAllDimensions(v, dimv);
    ndims_x = Array_getAllDimensions(x, dimx); 
    ndims_y = Array_getAllDimensions(y, dimy); 


    /* Note:
       structured points: x and y are undef
       rectilinear grid:  x and y are 1D arrays, their size can be different
       structured grid:   ndims of y = ndims of x, and all dimensions of y = all dimensions of x
       triangle mesh:     v is 1D, len(v)=N, x is Nx2 or Nx3 array, y is Mx3 array
    */

    // check for error: x can be used only with y
    // if only x is given, this may happen for 1D plots, and should not use it here for 2D plots
    if ( Array_getType(x) != undefArray && Array_getType(y) == undefArray ) {
        fprintf(stderr, "Warning: x cannot be used without y in 2D plots. Plot without x...\n");
        x = Array_new(undefArray);
    }

    vtkopts.title = title;
    vtkopts.imagefilename = imagefilename;
    vtkopts.xname = xname;
    vtkopts.yname = yname;
    vtkopts.auto_zoom = false;
    vtkopts.show_axes = false;
    vtkopts.do_square = false;

    if (use_polar_coordinates) {
        /**************/
        /* POLAR PLOT */
        /**************/
        //  check: v must be 2D while x and y must be 1D
        if (ndims_v != 2 || ndims_x != 1 || ndims_y != 1) {
            fprintf(stderr, "Error: For polar 2D plots, v should be a 2D array while x and y should be 1D arrays\n");
            return 1;
        }
        if (vtkopts.radius_is_first_dim) {
            //  check: 1st dim of v = length of r and  2nd dim of v = length of phi 
            if ( dimx[0] != dimv[0] ) {
                fprintf(stderr, "Error: size of x must = 1st dim of v. Use --polar=y if v is ordered oppositely.\n");
                return 1;
            }
            if ( dimy[0] != dimv[1] ) {
                fprintf(stderr, "Error: size of y must = 2nd dim of v. Use --polar=y if v is ordered oppositely.\n");
                return 1;
            }
        } else {
            //  check: 2nd dim of v = length of r and  1st dim of v = length of phi 
            if ( dimx[0] != dimv[1] ) {
                fprintf(stderr, "Error: size of x must = 2nd dim of v. Use --polar=x if v is ordered oppositely.\n");
                return 1;
            }
            if ( dimy[0] != dimv[0] ) {
                fprintf(stderr, "Error: size of y must = 1st dim of v. Use --polar=x if v is ordered oppositely.\n");
                return 1;
            }
        }
        retval = vtk_plotPolarGrid(v, min_v, max_v, x, min_x, max_x, y, min_y, max_y, vtkopts);
    }
    
    else if (do_trianglemesh) {
        /*****************/
        /* TRIANGLE MESH */
        /*****************/
        // check: v is 1D, x and y are 2D
        if (ndims_v != 1 || ndims_x != 2 || ndims_y != 2) {
            fprintf(stderr, "Error: For triangle mesh plots, v should be a 1D array while x and y should be 2D arrays\n");
            return 1;
        }
        // check: length(v) = 1st dim of x
        if (dimv[0] != dimx[0]) {
            fprintf(stderr, "Error: For triangle mesh plots, size of v = size of 1st dimension of x\n");
            return 1;
        }
        // check: 2nd dim of x is 2 or 3
        if (dimx[1] != 2 && dimx[1] != 3) {
            fprintf(stderr, "Error: For triangle mesh plots, x should be an Nx2 or Nx3 array of x-y[-z] co-ordinates of points\n");
            return 1;
        }
        // check: 2nd dim of y is 3
        if (dimy[1] != 3) {
            fprintf(stderr, "Error: For triangle mesh plots, y should be an Mx3 array of point triplets (triangles of points in x)\n");
            return 1;
        }
        // check: y is an int16 or int32 array
        if (Array_getType(y) != int16Array && Array_getType(y) != int32Array) {
            fprintf(stderr, "Error: y must be an array of integers (16 or 32 bit) for triangle mesh plots.\n");
            return 1;
        }
        retval = vtk_plotTriangleMesh(v, min_v, max_v, x, min_x, max_x, y, min_y, max_y, vtkopts);
    }

    else if (do_rectilinear) {
        /********************/
        /* RECTILINEAR GRID */
        /********************/
        //  check: x and y must be 1D
        if (ndims_x != 1 || ndims_y != 1) {
            fprintf(stderr, "Error: For rectilinear plots, x and y must be 1D arrays.\n");
            return 1;
        }
        //  check: v must be 2D 
        if (ndims_v != 2) {
            fprintf(stderr, "Error: For rectilinear plots, v should be a 2D array.\n");
            return 1;
        }
        //  check: 1st dim of v = length of x
        if ( dimx[0] != dimv[0] ) {
            fprintf(stderr, "Error: size of x must = 1st dim of v for rectilinear plots (x and y is 1D).\n");
            return 1;
        }
        //  check: 2nd dim of v = length of y
        if ( dimy[0] != dimv[1] ) {
            fprintf(stderr, "Error: size of y must = 2nd dim of v for rectilinear plots (x and y is 1D).\n");
            return 1;
        }
        vtkopts.auto_zoom = true;
        vtkopts.show_axes = !hide_axes;
        vtkopts.do_square = do_squareplots;
        vtkopts.transposed = transpose;
        retval = vtk_plotRectilinearGrid(v, min_v, max_v, x, min_x, max_x, y, min_y, max_y, vtkopts);
    }
    
    else if (ndims_v == 1 && ndims_x == 1 && ndims_y == 1) {
        /*******************/
        /* STRUCTURED GRID 1D */
        /*******************/
        //  check: dims of x = dims of v
        if (dimx[0] != dimv[0]) {
            fprintf(stderr, "Error: For structured grid 1D plots, v and x must have the same dimension.\n");
            return 1;
        }
        //  check: dims of y = dims of v
        if (dimy[0] != dimv[0]) {
            fprintf(stderr, "Error: For structured grid 1D plots, v and y must have the same dimension.\n");
            return 1;
        }
        vtkopts.auto_zoom = true;
        vtkopts.show_axes = false;
        vtkopts.do_square = do_squareplots;
        vtkopts.transposed = transpose;
        retval = vtk_plotStructuredGrid1D(v, min_v, max_v, x, min_x, max_x, y, min_y, max_y, vtkopts);
    }

    else if (ndims_x == 1 && ndims_y == 1) {
        /*********************************************************/
        /* plot a 2D array as is but with x and y as axis values */
        /*********************************************************/
        vtkopts.auto_zoom = true;
        vtkopts.show_axes = !hide_axes;
        vtkopts.do_square = do_squareplots;
        vtkopts.transposed = transpose;
        retval = vtk_plotArray(v, min_v, max_v, x, min_x, max_x, y, min_y, max_y, vtkopts);
    }

    else if (ndims_x == 0 && ndims_y == 0) {
        /*************************/
        /* plot a 2D array as is */
        /*************************/
        vtkopts.auto_zoom = true;
        vtkopts.show_axes = !hide_axes;
        vtkopts.do_square = do_squareplots;
        vtkopts.transposed = transpose;
        retval = vtk_plotArray(v, min_v, max_v, NULL, 0, dimv[0]-1, NULL, 0, dimv[1]-1, vtkopts);
    }

    else {
        fprintf(stderr,"Error: Could not figure out what kind of 2D plot to make from your data:\n");
        fprintf(stderr,"       v: [%d ", dimv[0]);
        for (i=1; i<ndims_v; i++) fprintf(stderr, ", %d", dimv[i]);
        fprintf(stderr,"]  x: [ ");
        for (i=0; i<ndims_x; i++) fprintf(stderr, " %d", dimx[i]);
        fprintf(stderr,"]  y: [ ");
        for (i=0; i<ndims_y; i++) fprintf(stderr, " %d", dimy[i]);
        fprintf(stderr,"]\n");
        fprintf(stderr,"       Options -polar or -triangle-mesh was NOT given\n");
        return 1;
    }
        
    return retval;
}
#endif                    

/** X-Y plot one variable over time with xmgrace (or call plotVar2D).
  * For each requested timestep
  *   - read in the variable
  *   - if it is 2D slice and 2D plot is requested, call plotVar2D
  *   - create X axis variable if not given as argument
  *   - print as text or call graceplot 
  *   
  */
int plotVar( DataFile dfv, VarInfo vi, char* outspec, 
              Array x, char *xname, double min_x_in, double max_x_in,
              Array y, char *yname, double min_y_in, double max_y_in,
              Array t, char *tvar
              ) 
{
    int iter, tb, te, retval=0;
    char *vname = vi.dispname;
    char *plottitle = title;
    char *legend = NULL;
    char tmp[128], outidx[32], timestr[32], outnamespec[256];
    bool should_free_x = false;
    double min_v, max_v, min_x, max_x; //, min_y, max_y;
    Array v = Array_new(undefArray);
#ifdef VTK
    Array vT;
#endif

    if (xname && xname[0] == '/') xname++; // get rid of starting / in names
    if (yname && yname[0] == '/') yname++;
    if (vname && vname[0] == '/') vname++;

    // set iterative dimension
    if (timeDimidx > -1) {
        // negative index =  last+index
        if (timeFrom < 0) tb = vi.dimsize[timeDimidx] + timeFrom % vi.dimsize[timeDimidx] + dfv.time_start;
        else tb = timeFrom;
        if (timeSteps < 0) te = vi.dimsize[timeDimidx] + timeSteps % vi.dimsize[timeDimidx] + dfv.time_start;
        else te = tb + timeSteps*timeStepping - 1;
        // error checking
        if (tb >= vi.dimsize[timeDimidx] + dfv.time_start) {
            fprintf(stderr,"Warning: time begin index is > steps available for variable %s\n", vi.name);
            return 0;  // not an error but cannot make plots for this variable
        }
        if (te >= vi.dimsize[timeDimidx] + dfv.time_start) {
            fprintf(stderr,"Warning: time end index is > steps available for variable %s\n", vi.name);
            te = vi.dimsize[timeDimidx] - 1;
        }
         if (verbose) printf("timeFrom = %ld  timeSteps = %ld  timeStepping = %ld -> from = %d  to = %d\n", 
             timeFrom, timeSteps, timeStepping, tb, te);
    } else {
        // no iter dimension was specified
        tb = 0;
        te = 0;
    }

    if (verbose) printf("variable %s ...\n", vname); 
    for (iter = tb; iter <= te; iter+=timeStepping) {
        if (verbose) printf("  iteration %d ...\n",iter); 
        if (timeDimidx > -1) {
            istart[timeDimidx] = iter;
            icount[timeDimidx] = 1;
            // make the output name idx string based on iter and variable t
            if (t != NULL && Array_getType(t) != undefArray) {
                Array_strvalue(t, iter, timestr);
                Array_strvalue_padded(t, iter, outidx, outidxWidth);
                if (verbose>1) printf("    Output file index: %s\n", timestr);
            } else {
                snprintf(timestr, 32, "%d", iter);
                snprintf(outidx, 32, "%0*d", outidxWidth, iter);
            }
            snprintf(outnamespec, 256, "%s.%s", outspec, outidx);
        } else if (timeFix > -1) { // timefix counts only if there is no iteration
            snprintf(timestr, 32, "%d", timeFix);
            snprintf(outnamespec, 256, "%s.%0*d", outspec, outidxWidth, timeFix);
        } else {
            strncpy(outnamespec, outspec, 256); 
        }
        // read in variable (Array v will be allocated)

        _tstart();
        v = reader_read_var(dfv, vi, istart, icount);
        _tend();
        _tdiff(&tp);
        if (verbose>1) printf("     time to read %s = %d.%6.6d sec\n", vi.name, tp.tv_sec, tp.tv_usec);
        if ( Array_errno(v) ) {
            fprintf(stderr, "Error: could not read var %s, iteration %d from %s\n", vi.name, iter, vfile);
            exit(5);
        }
        //if (verbose) printf("    v array length = %d\n", Array_length(v));
#ifdef VTK
        // if --transpose then transpose v now
        if (transpose && Array_getDimensions(v) == 2) {
            if (verbose) printf("   Transpose variable %s ...\n", vname);
            vT = Array_transpose(v);
            if ( Array_getType(vT) == undefArray) {
                return 2;
            }
            Array_free(v);
            v = vT;
        }
#endif
        
#ifdef VTK
        //if (plot_in_2D && !output_ascii && 
        //    (Array_getDimensions(v) == 2 || do_trianglemesh)) 
        if (!output_ascii)
        {
            determineMinMax(vname, v, &min_v, &max_v);
            if (plottitle == NULL) {
                  snprintf(tmp, 128, "%s", vname);
                  plottitle = tmp;
            }
            retval = plotVar2D( plottitle, v, outnamespec, min_v, max_v, 
                                x, xname, min_x_in, max_x_in,
                                y, yname, min_y_in, max_y_in);
            // write minmax into file
            if (!retval && minmaxfile != NULL && !use_global_minmax) {
                if (verbose>1) printf("    print minmax\n");
                minmax_print(vname, iter, Array_min(v), Array_max(v));
            }
            Array_free(v);
            if (retval) break;  // exit after first error
            continue;
        }
#endif                    
        
        // if x is empty, let's create a [0..n-1] array here 
        if (x == NULL || Array_getType(x) == undefArray) {
            min_x = 0;
            max_x = Array_length(v)-1;
            x = Array_indgen((int)min_x,(int)max_x,1);
            should_free_x = true;
            if (verbose>1) printf("    created x array from [%d..%d], len=%ld, type=%s\n", 
                (int)min_x, (int)max_x, Array_length(x), arrayTypeStrings[Array_getType(x)]);
            // set to min/max if provided as argument
            if (!isnan(min_x_in)) min_x = min_x_in;
            if (!isnan(max_x_in)) max_x = max_x_in;
            if (verbose>1) printf("    x min/max %d..%d\n", (int)min_x, (int)max_x); 
        } else {
            min_x = min_x_in;
            max_x = max_x_in;
        }

        if (output_ascii) {
            // print values into text file
            print_data_1D(outnamespec, xname, vname, x, v);

        } else {
#ifdef XMGRACE        
            // make plot
            if (iter==tb) n1Dvars++; // this variable is plotted in 1D
            // .png, .agr will be added in grace_plot to outnamespec
            determineMinMax(vname, v, &min_v, &max_v);
            if (!skip_undef || !Array_is_data_undef_all(v))
            {
                if (plottitle == NULL) {
                    if (xname) snprintf(tmp, 128, "%s vs. %s", vname, xname);
                    else snprintf(tmp, 128, "%s", vname);
                    if (verbose) printf("    plot %s  min=%le  max=%le\n", outnamespec, min_v, max_v);
                    plottitle = tmp;
                }

                // init plot now if needed (3 cases: multiplot, multiplot_time, normal) 
                if (multiplot) {
                    // error check (should not reach because checkArgs() should have stopped already)
                    if (iter != tb) {
                        fprintf(stderr, "Error: Plotter cannot plot several variables into one image _and_ loop over time to generate many images.\n");
                        fprintf(stderr, "In case of --multiplot, do not use time spec in --start.\n");
                        fprintf(stderr, "Use --multiplot-time to plot several timesteps of one variable on one plot.\n");
                        exit(180);
                    }
                    // init for first var and first time only
                    if (n1Dvars == 1 && iter==tb) {
                        if (title == NULL) {
                            snprintf(tmp, 128, "Multiplot");
                            plottitle = tmp;
                        }
                        grace_init_plot (plottitle, subtitle, xname, vname, 0.30);
                    }
                    legend = vname;
                } else if (multiplot_time) {
                    // init plot at the first timestep
                    if (iter==tb) {
                        grace_init_plot (plottitle, subtitle, xname, vname, 0.157051);
                    }
                    legend = timestr;
                } else {
                    grace_init_plot (plottitle, subtitle, xname, vname, 0.0);
                    legend = NULL;
                }
                
                // draw this variable and time
                grace_draw_plot( Array_length(v), x, v, vname, timestr, legend, min_x, max_x, min_v, max_v );

                // save image if not multiplot_time or multiplot
                if (!multiplot_time && !multiplot)
                    grace_save_plot(outnamespec, output_agr);

            } else {
                fprintf(stderr, "    plot %s is skipped because values are undefined\n", outnamespec);
            }
#else /* XMGRACE not available */
            fprintf(stderr, "ERROR: this code is not compiled with xmgrace, so it cannot make 1D plots. Either do 2D plots, or print text with -p or --output-xml\n");
            break; /* break the time loop */

#endif
        }

        // write minmax into file
        if (minmaxfile != NULL && !use_global_minmax) {
            if (verbose>1) printf("    print minmax\n");
            minmax_print(vname, iter, Array_min(v), Array_max(v));
        }

        // free array(s) up for the next iteration
        Array_free(v);
        if (should_free_x) { 
            Array_free(x);
            should_free_x = false;
            x = NULL;
        }
    }

#ifdef XMGRACE
    // save image if multiplot_time 
    if (multiplot_time) {
        // use outspec to save instead of outnamespec which has time in it
        grace_save_plot(outspec, output_agr); 
    }
#endif

    if (verbose>1) printf("    return from plotVar\n");
    return retval;
}

static bool conformsToDimSpec(VarInfo vi) {
    if (timeDimidx > vi.ndims) {
            fprintf(stderr,"The time dimension (%ld) is out of the dimensions of this variable %s (%d). Skip it.\n", 
                    timeDimidx, vi.name, vi.ndims);
            return false;
    }
    if (timeDimidx == 0 && vi.ndims == 1) { 
            fprintf(stderr,"Variable %s has only 1 dimension and time is specified. Skip it.\n", vi.name);
            return false;
    }
    return true;
}

static bool matchesAMask(char *name) {
    int excode;
    int i;
    int startpos=0; // to match with starting / or without
    regmatch_t pmatch[1] = {{ (regoff_t) -1, (regoff_t) -1}};

    for (i=0; i<nmasks; i++) {
        if (use_regexp) {
            excode = regexec (&(varregex[i]), name, 1, pmatch, 0);
            if (name[0] == '/') // have to check if it matches from the second character too
                startpos = 1;
            if (excode == 0 &&                  // matches
                (pmatch[0].rm_so == 0 || pmatch[0].rm_so == startpos) &&         // from the beginning
                pmatch[0].rm_eo == strlen(name) // to the very end of the name
               ) {
                if (verbose>1)
                    printf("Name %s matches regexp %i %s\n", name, i, varmask[i]);
                //printf("Match from %d to %d\n", (int) pmatch[0].rm_so, (int) pmatch[0].rm_eo);
                return true;
            }
        } else {
            // use shell pattern matching
            if (varmask[i][0] != '/' && name[0] == '/')
                startpos = 1;
            if ( fnmatch( varmask[i], name+startpos, FNM_FILE_NAME) == 0) {
                if (verbose>1)
                    printf("Name %s matches varmask %i %s\n", name, i, varmask[i]);
                return true; 
            }
        }
    }
    return false;
}

/** Main body of work.
  * - open data file(s)
  * - read in X and Y variables if specified
  * - for each matching variable, call plotVar()
  */
int doWork() {
    char buf[256], *varbasename; // to get base name of a variable with full path
    DataFile df_v = DataFile_new();
    DataFile df_x = DataFile_new();
    DataFile df_y = DataFile_new();
    DataFile df_t = DataFile_new();
    Array x = Array_new(undefArray); // we do not know the type yet
    Array y = Array_new(undefArray); // we do not know the type yet
    Array t = Array_new(undefArray); // we do not know the type yet
    char outspec[256];
    int i, excode;
    int nVarsMatched = 0;
    double min_x = xmin, max_x = xmax, min_y = ymin, max_y = ymax;
#ifdef VTK
    int ndims_x, ndims_y, dimx, dimy; // temp vars for error checking
#endif
    bool outpath_is_dir;
    int retval = 0;
    
    outpath_is_dir  = is_dir(outpath);  // so we run stat only once (+ in checkArgs)

    // open yfile
    _tstart();
    df_v = reader_open(vfile, vfiletype, nameattr);
    _tend();
    _tdiff(&tp);
    if (verbose>1) printf("     time to open %s = %d.%6.6d sec\n", vfile, tp.tv_sec, tp.tv_usec);
    if (df_v.fd == -1 && df_v.fh == -1) {
        fprintf(stderr, "Error: could not open file %s\n", vfile);
        retval=1; goto finalize;
    }
    
    // read x var if should be read from xfile
    if (xvar != NULL) {
        // open xfile, if not the same as vfile
        if (strcmp(xfile, vfile)) {
            _tstart();
            df_x = reader_open(xfile, xfiletype, nameattr);
            _tend();
            _tdiff(&tp);
            if (verbose>1) printf("     time to open %s = %d.%6.6d sec\n", xfile, tp.tv_sec, tp.tv_usec);
            if (df_x.fd == -1 && df_x.fh == -1) {
                fprintf(stderr, "\nError: could not open file %s for x var %s\n", xfile, xvar);
                retval=2; goto finalize;
            }
        } else {  // cannot be both NULL, because we check that in checkArgs
            if (verbose>2) printf("x file is same as var file %s\n", vfile);
            df_x = df_v;
        }
        // debug
        //printf("df = %d\n", df_x.fd);
        //print_DFinfo(df_x);
        
        // read in x variable (Array x will be allocated)
        _tstart();
        x = reader_read_var_byname(df_x, xvar, xistart, xicount);
        _tend();
        _tdiff(&tp);
        if (verbose>1) printf("     time to read x %s = %d.%6.6d sec\n", xvar, tp.tv_sec, tp.tv_usec);
        if ( Array_errno(x) ) {
            fprintf(stderr, "\nError: could not read x var %s from %s\n", xvar, xfile);
            retval=3; goto finalize;
        }
        if (isnan(min_x)) min_x = Array_min(x); // if xmin is not argument, get from array
        if (isnan(max_x)) max_x = Array_max(x);
        
        //printf("Var %s dump\n:", xvar);
        //Array_print(x);
    } // x remains undefArray if not read in here

#ifdef VTK
    // read y var if should be read from yfile
    if (yvar != NULL) {
        // open yfile, if not the same as xfile or vfile
        if (!strcmp(yfile, xfile)) {  // xfile = vfile if it was not set otherwise
            if (verbose>2) printf("y file is same as x file %s\n", xfile);
            df_y = df_x;
        } else if (!strcmp(yfile, vfile)) { // yfile is set in setDefaultsAfterArgs()
            if (verbose>2) printf("y file is same as var file %s\n", vfile);
            df_y = df_v;
        } else {
            df_y = reader_open(yfile, yfiletype, nameattr);
            if (df_y.fd == -1 && df_y.fh == -1) {
                fprintf(stderr, "\nError: could not open file %s for y var %s\n", yfile, yvar);
                retval=4; goto finalize;
            }
        }
        // debug
        //printf("df = %d\n", df_y.fd);
        //print_DFinfo(df_y);
        
        // read in y variable (Array y will be allocated)
        _tstart();
        y = reader_read_var_byname(df_y, yvar, yistart, yicount);
        _tend();
        _tdiff(&tp);
        if (verbose>1) printf("     time to read y %s = %d.%6.6d sec\n", yvar, tp.tv_sec, tp.tv_usec);
        if ( Array_errno(y) ) {
            fprintf(stderr, "\nError: could not read y var %s from %s\n", yvar, yfile);
            retval=5; goto finalize;
        }
        if (!isnan(ymin)) min_y = ymin;
        else min_y = Array_min(y);
        if (!isnan(ymax)) max_y = ymax;
        else max_y = Array_max(y);
        
        // must be the same number of dimensions as x (and x exist if we are at this point)
        ndims_x = Array_getDimensions(x);
        ndims_y = Array_getDimensions(y);
        if (ndims_x != ndims_y) {
            fprintf(stderr, "Error: # of dimensions of x (=%d) and y (=%d) must be the same for 2D plots\n", 
                    ndims_x, ndims_y);
            retval=6; goto finalize;
        }
        // if > 1 dims and not a triangle mesh is requested then
        //   the dimensions themselves should also be equal (for 1D, x and y is probably different)
        if (!do_trianglemesh && ndims_x > 1) {
            for (i=0; i<ndims_x; i++) {
                dimx = Array_getDimensionSize(x,i);
                dimy = Array_getDimensionSize(y,i);
                if (dimx != dimy) {
                    fprintf(stderr, "Error: dimension %d of x (=%d) and y (=%d) must be the same for 2D plots\n", 
                            i, dimx, dimy);
                    retval=7; goto finalize;
                }
            }
        }
        // for triangle mesh, x and y should have 2 dimensions
        if (do_trianglemesh && ndims_x != 2) {
            fprintf(stderr, "Error:  x (=%d) and y (=%d) must be 2D arrays for triangle mesh plots\n", 
                    ndims_x, ndims_y);
            retval=6; goto finalize;
        }
        //printf("Var %s dump\n:", yvar);
        //Array_print(y);
    } 
    // y remains undefArray if not read in here
    // otherwise y is read in and it has the same dimensions as x
#endif

    // read t var if should be read from tfile
    if (tvar != NULL) {
        // open tfile, if not the same as vfile
        if (strcmp(tfile, vfile)) {
            df_t = reader_open(tfile, tfiletype, nameattr);
            if (df_t.fd == -1 && df_t.fh == -1) {
                fprintf(stderr, "\nError: could not open file %s for t var %s\n", tfile, tvar);
                retval=8; goto finalize;
            }
        } else {  // cannot be both NULL, because we check that in checkArgs
            if (verbose>2) printf("t file is same as var file %s\n", vfile);
            df_t = df_v;
        }
        
        // read in t variable (Array t will be allocated)
        t = reader_read_var_byname(df_t, tvar, tistart, ticount);
        if ( Array_errno(t) ) {
            fprintf(stderr, "\nError: could not read t var %s from %s\n", tvar, tfile);
            retval=9; goto finalize;
        }
    } // t remains undefArray if not read in here

    // Open minmax file, so that codes deeper in the calls can write/read minmax data
    if (minmaxfile)
        minmax_open(minmaxfile, (use_global_minmax ? 1 : 0));

    // plot variables that match any of the masks
    for (i=0; i < df_v.nvars; i++) {
        if (!matchesAMask(df_v.varinfo[i].name))
            continue;
        if (!conformsToDimSpec(df_v.varinfo[i])) 
            continue;
        excode = 0;
        nVarsMatched++;
        // get base name of the variable (can be a full path in HDF5/ADIOS)
        strncpy(buf, df_v.varinfo[i].dispname, 256);
        varbasename = basename(buf);
            
        // prepare output name (without numbering and extension)
        if (multiplot) {
            snprintf(outspec, 256, "%s", outpath);
        } else if (output_separate_dirs) {
            snprintf(outspec, 256, "%s/%s", outpath, df_v.varinfo[i].dispname); 
            excode = createdir_recursive(outspec);
            if (!excode) {
                if (df_v.varinfo[i].dispname[0] == '/')
                    snprintf(outspec, 256, "%s%s/%s", outpath, df_v.varinfo[i].dispname, varbasename); 
                else
                    snprintf(outspec, 256, "%s/%s/%s", outpath, df_v.varinfo[i].dispname, varbasename); 
            }
        } else if (outpath_is_dir) {
            if (varbasename[0] == '/')
                snprintf(outspec, 256, "%s%s", outpath, varbasename); 
            else
                snprintf(outspec, 256, "%s/%s", outpath, varbasename); 
        } else {
            if (nVarsMatched == 1)
                snprintf(outspec, 256, "%s", outpath);
            else {
                fprintf(stderr, "\nError: Plotting several variables into one output file (%s) is not supported."
                    "Specify a directory as --output \n", outpath);
                break;
            }
        }
        if (!excode) {
            retval = plotVar( df_v, df_v.varinfo[i], outspec, 
                              x, (xaxisname != NULL ? xaxisname : xvar), min_x, max_x, 
                              y, (yaxisname != NULL ? yaxisname : yvar), min_y, max_y,
                              t, tvar);
        } else {
            retval = excode;
        }
        if (retval) break;  // break after first error
    }
#ifdef XMGRACE
    if (multiplot && n1Dvars > 0) {
        // in case of multiplot we save the plot image here
        grace_save_plot(outpath, output_agr);
    }
#endif

    if (!retval && nVarsMatched == 0) {
        fprintf(stderr, "\nError: None of the variables matched any yvar name/regexp you provided\n");
        retval = 10;
    }
    

finalize:    // we jump here in case of errors too

    if (minmaxfile)    minmax_close();

    // close data file(s)
    if (tfile != NULL && strcmp(tfile, xfile) && strcmp(tfile, vfile)) 
        reader_close(df_t);
    if (yfile != NULL && strcmp(yfile, xfile) && strcmp(yfile, vfile)) 
        reader_close(df_y);
    if (xfile != NULL && strcmp(xfile, vfile)) 
        reader_close(df_x);
    reader_close(df_v);

    return retval; 
}

/** Just list variables matching the masks (or all)
  */
int doList() {
    DataFile df_v = DataFile_new();
    int i, j, maxlen, len;
    int nVarsMatched = 0;
    
    // open yfile
    df_v = reader_open(vfile, vfiletype, nameattr);
    if (df_v.fd == -1 && df_v.fh == -1) {
        fprintf(stderr, "Error: could not open file %s\n", vfile);
        exit(1);
    }
   
    // calculate max length of variable names in the first round
    maxlen = 4;
    for (i=0; i < df_v.nvars; i++) {
        if (nmasks > 0 && !matchesAMask(df_v.varinfo[i].name))
            continue;
        len = strlen(df_v.varinfo[i].name);
        if (len > maxlen) maxlen = len;
    }
        
    // list variables that match any of the masks (or all if no masks given)
    for (i=0; i < df_v.nvars; i++) {
        if (nmasks > 0 && !matchesAMask(df_v.varinfo[i].name))
            continue;
        //printf("%s\t%-28s", arrayTypeStrings[df_v.varinfo[i].type], df_v.varinfo[i].name); 
        printf("%s\t%-*s", arrayTypeStrings[df_v.varinfo[i].type], maxlen, df_v.varinfo[i].name); 
        if (df_v.varinfo[i].ndims > 0) {
            printf("\t {%d", df_v.varinfo[i].dimsize[0]);
            for (j=1; j < df_v.varinfo[i].ndims; j++)
                    printf(", %d", df_v.varinfo[i].dimsize[j]);
            printf("}");
        } else {
            printf("\t scalar");
        }
        if (df_v.varinfo[i].name != df_v.varinfo[i].dispname) {
            printf("\t %s=%s", nameattr, df_v.varinfo[i].dispname);
        }
        printf("\n");
        nVarsMatched++;
    }

    // close data file(s)
    reader_close(df_v);

    if (nVarsMatched == 0) {
        fprintf(stderr, "\nError: None of the variables matched any yvar name/regexp you provided\n");
        return 4;
    }

    return 0; 
}

/** Main */
int main( int argc, char *argv[] ) {
   int retval = 0;
   int i; 
   long int tmp;

#ifdef VTK
   error_check_sizeofbool(sizeof(char));
#endif 

   init_globals();

   prgname = strdup(argv[0]);

   /* other variables */
   char c, last_c='_';
   int last_opt = -1;
   /* Process the arguments */
   while ((c = getopt_long_only(argc, argv, optstring, options, NULL)) != -1) {
        switch (c) {
                case 'h':
                    display_help();
                    return 0;
                case 'l':
                    list_only=true;
                    break;
                case 'd':
                    verbose++;
                    break;
                case 'o':
                    outpath = strndup(optarg,256);
                    break;
                case 't':
                    tvar = strndup(optarg,256);
                    break;
                case 'x':
                    xvar = strndup(optarg,256);
                    break;
                case 'y':
                    yvar = strndup(optarg,256);
                    break;
                case 'v':
                    varmask[nmasks] = strndup(optarg,256);
                    nmasks++;
                    break;
                case 'f':
                    vfile = strndup(optarg,256);
                    break;
                case 's':
                    start = strndup(optarg,256);
                    break;
                case 'c':
                    count = strndup(optarg,256);
                    break;
                case 'p': 
                    output_ascii = true;
                    if (optarg != NULL) {
                        errno = 0;
                        if (optarg[0] == '=') optarg++; // get rid of = in -p=4 string
                        tmp = strtol(optarg, (char **)NULL, 0);
                        if (errno) {
                            fprintf(stderr, "Error: could not convert print width value: %s\n", optarg);
                            return 1;
                        }
                        ascii_width=tmp;
                    }
                    break;
                break;

                case 0:
                    switch(opt) {
                        case OPT_OUTPUT_XML:
                            output_xml = true;
                            output_ascii = true;
                            break;
                        case OPT_INPUT_X:
                            xfile = strndup(optarg,256);
                            break;
                        case OPT_INPUT_T:
                            tfile = strndup(optarg,256);
                            break;
                        case OPT_TYPE_V:
                            vfiletype = reader_getFileType(optarg);
                            if (vfiletype == undef_file) {
                                fprintf(stderr, "Invalid file type: %s. Options: netcdf, hdf5, adios\n", optarg);
                                return 2;
                            }
                            break;
                        case OPT_TYPE_X:
                            xfiletype = reader_getFileType(optarg);
                            if (xfiletype == undef_file) {
                                fprintf(stderr, "Invalid file type for x: %s. Options: netcdf, hdf5, adios\n", optarg);
                                return 2;
                            }
                            break;
                        case OPT_TYPE_T:
                            tfiletype = reader_getFileType(optarg);
                            if (tfiletype == undef_file) {
                                fprintf(stderr, "Invalid file type for t: %s. Options: netcdf, hdf5, adios\n", optarg);
                                return 2;
                            }
                            break;
                        case OPT_MINMAXFILE:
                            minmaxfile = strndup(optarg,256);
                            break;
                        case OPT_XSTART:
                            xstart = strndup(optarg,256);
                            break;
                        case OPT_XCOUNT:
                            xcount = strndup(optarg,256);
                            break;
                        case OPT_SEPARATE_DIRS:
                            output_separate_dirs = true;
                            break;
                        case OPT_OUTPUT_AGR:
                            output_agr = true;    
                            break;
                        case OPT_USE_GLOBALMINMAX:
                            use_global_minmax = true;
                            break;
                        case OPT_VMIN:
                            errno = 0;
                            vmin = strtod(optarg, (char **)NULL);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert xmin value: %s\n", optarg);
                                return 1;
                            }
                            break;
                        case OPT_VMAX:
                            errno = 0;
                            vmax = strtod(optarg, (char **)NULL);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert xmax value: %s\n", optarg);
                                return 1;
                            }
                            break;
                        case OPT_XMIN:
                            errno = 0;
                            xmin = strtod(optarg, (char **)NULL);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert xmin value: %s\n", optarg);
                                return 1;
                            }
                            break;
                        case OPT_XMAX:
                            errno = 0;
                            xmax = strtod(optarg, (char **)NULL);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert xmax value: %s\n", optarg);
                                return 1;
                            }
                            break;
                        case OPT_XAXISNAME:
                            xaxisname = strndup(optarg,256);
                            break;
                        case OPT_TIMEFIX:
                            errno = 0;
                            timeFix = strtod(optarg, (char **)NULL);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert timeFix value: %s\n", optarg);
                                return 1;
                            }
                            break;
                        case OPT_NAMEATTR:
                            nameattr = strndup(optarg,256);
                            break;
                        case OPT_OUTPUT_INDEX_WIDTH:
                            errno = 0;
                            outidxWidth = strtol(optarg, (char **)NULL, 0);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert time field width value: %s\n", optarg);
                                return 1;
                            }
                            break;
                        case OPT_SKIP_UNDEF:
                            skip_undef = true;
                            break;
                        case OPT_USE_REGEXP:
                            use_regexp = true;
                            break;
                        case OPT_PRINT_PROVENANCE:
                            print_provenance = true;
                            break;
                        case OPT_MULTIPLOT:
                            multiplot = true;
                            break;
                        case OPT_MULTIPLOT_TIME:
                            multiplot_time = true;
                            break;
                        case OPT_HIDE_AXES:
                            hide_axes = true;
                            break;
                        case OPT_IMGSIZE:
                            errno = 0;
                            sizeX = strtol(optarg, (char **)NULL, 0);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert sizeX field width value: %s\n", optarg);
                                return 1;
                            }
                            sizeY = sizeX; // may be overwritten by 2nd argument
                            last_opt = opt;
                            break;
                        case OPT_FOREGROUND:
                            errno = 0;
                            parseRGB(optarg, fgColor);
                            break;
                        case OPT_BACKGROUND:
                            errno = 0;
                            parseRGB(optarg, bgColor);
                            break;
                        case OPT_TITLE:
                            title = strndup(optarg,256);
                            break;
                        case OPT_SUBTITLE:
                            subtitle = strndup(optarg,256);
                            break;
#ifdef VTK
                        case OPT_INPUT_Y:
                            yfile = strndup(optarg,256);
                            break;
                        case OPT_TYPE_Y:
                            yfiletype = reader_getFileType(optarg);
                            if (yfiletype == undef_file) {
                                fprintf(stderr, "Invalid file type for x: %s. Options: netcdf, hdf5, adios\n", optarg);
                                return 2;
                            }
                            break;
                        case OPT_YSTART:
                            ystart = strndup(optarg,256);
                            break;
                        case OPT_YCOUNT:
                            ycount = strndup(optarg,256);
                            break;
                        case OPT_YMIN:
                            errno = 0;
                            ymin = strtod(optarg, (char **)NULL);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert ymin value: %s\n", optarg);
                                return 1;
                            }
                            break;
                        case OPT_YMAX:
                            errno = 0;
                            ymax = strtod(optarg, (char **)NULL);
                            if (errno) {
                                fprintf(stderr, "Error: could not convert ymax value: %s\n", optarg);
                                return 1;
                            }
                            break;
                        case OPT_YAXISNAME:
                            yaxisname = strndup(optarg,256);
                            break;
                        case OPT_2D_COLORMAP:
                            colormap = vtk_useColormap(optarg);
                            if (colormap == NULL)
                                return 1;
                            break;
                        case OPT_2D_CONTOUR:
                            vtkopts.do_contour  = true;
                            if (optarg != NULL) {
                                errno = 0;
                                tmp = strtol(optarg, (char **)NULL, 0);
                                if (errno) {
                                    fprintf(stderr, "Error: could not convert countour value: %s\n", optarg);
                                    return 1;
                                }
                                vtkopts.numContours = tmp;
                            }
                            break;
                        case OPT_POLAR:
                            use_polar_coordinates = true;
                            vtkopts.radius_is_first_dim = true;
                            if (optarg != NULL) {
                                if (strlen(optarg)==1 && (optarg[0] == 'x' || optarg[0] == 'X'))
                                    vtkopts.radius_is_first_dim = true;
                                else if (strlen(optarg)==1 && (optarg[0] == 'y' || optarg[0] == 'Y'))
                                    vtkopts.radius_is_first_dim = false;
                                else {
                                    fprintf(stderr, "Error: --polar parameter can be only x or y, not %s\n", optarg);
                                    return 1;
                                }
                            } 
                            break;
                        case OPT_MAKESQUAREPLOT:
                            do_squareplots = true;
                            break;
                        case OPT_TRIANGLEMESH:
                            do_trianglemesh = true;
                            break;
                        case OPT_RECTILINEAR:
                            do_rectilinear = true;
                            break;
                        case OPT_BALANCE_COLORMAP:
                            vtkopts.balance_colormap = true;
                            break;
                        case OPT_ZONAL:
                            vtkopts.node_centered = false;
                            break;
                        case OPT_TRANSPOSE:
                            transpose = true;
                            break;
#endif
                    }
                    break;

                case 1:
                    /* This means a field is unknown, or could be multiple arg or bad arg*/
                    if (last_opt==OPT_IMGSIZE) {  // --imgsize 2nd arg
                        errno = 0;
                        sizeY = strtol(optarg, (char **)NULL, 0);
                        if (errno) {
                            fprintf(stderr, "Error: could not convert img size Y value: %s\n", optarg);
                            return 1;
                        }
                        last_opt = -1;
                    }
                    /*
                    else if (last_c=='t') {  // --time 2nd arg
                        errno = 0;
                        timeTo = strtol(optarg, (char **)NULL, 0);
                        if (errno) {
                            fprintf(stderr, "Error: could not convert time value: %s\n", optarg);
                            return 1;
                        }
                        //printf("Time set to %d - %d\n", timeFrom, timeTo);
                    } */
                    else { 
                    
                        fprintf(stderr, "Unrecognized argument: %s\n", optarg);
                        return 1;
                    
                    }
                    
                    break;
                default:
                    printf("Processing default: %c\n", c);
                    break;
        } /* end switch */
        last_c = c;
   } /* end while */

   if (!checkArgs())
       return 1;

   setDefaultsAfterArgs();
   processDimSpecs();
   if (verbose) 
       printSettings();
   
   /* Start working */
   if (list_only) 
       retval = doList();
   else
       retval = doWork();

   /* Free allocated memories */
   myfree(prgname);
   myfree(outpath);
   myfree(xvar);
   myfree(yvar);
   for (i=0; i<nmasks; i++) {
        myfree(varmask[i]);
        regfree(&(varregex[i]));
   }
   if (yfile != NULL && strcmp(yfile, vfile) && strcmp(yfile, xfile)) 
       myfree(yfile);
   if (xfile != NULL && strcmp(xfile, vfile)) 
       myfree(xfile);
   myfree(vfile);
   myfree(minmaxfile);

   return retval; 
}



/**
  Print out a 1D array
  format 1, with the X values as well with "X Y" in each line (ascii_width=0, default), or
  format 2, in a matrix format of 'ascii_width' columns "X: Y1 Y2...Y<ascii_width>".
  uses global var: outpath, ascii_width
*/
static int print_data_1D(char *outnamespec, char *xname, char* vname, Array x, Array v) {
    char *fn;
    char outfile[256];
    FILE *f;
    int len = min(Array_length(x), Array_length(v));
    int i,j;
    char xstr[128], vstr[128];


    //printf ("-- print: vname=%s, xname=%s\n", vname, xname);
    if ( outpath == NULL) {
        fn = strndup("/dev/stdout", 32);
        //printf ("-- print to stdout %s\n", fn);
    } else {
        if (output_xml) 
            snprintf(outfile, 256, "%s.xml", outnamespec);
        else 
            snprintf(outfile, 256, "%s.txt", outnamespec);
        fn = strndup(outfile, 256);
        if (verbose) printf("    print data to %s\n", outfile);
    }

    if ((f = fopen(fn,"w")) == NULL) {
        fprintf(stderr, "Error at opening for writing file %s: %s\n",
                fn, strerror(errno));
        return 1;
    }


    if (output_xml) {
        fprintf(f, "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
        fprintf(f, "<plot xname=\"%s\" yname=\"%s\">\n", xname, vname);
        // print "<point> <X>X</X>  <Y>Y</Y> </point>"
        for (i=0; i<len; i++) {
            Array_strvalue(x, i, xstr);
            Array_strvalue(v, i, vstr);
            fprintf(f,"  <point> <X>%s</X>  <Y>%s</Y> </point>\n", xstr, vstr);
        }
        fprintf(f, "</plot>\n");
    } else if (ascii_width == 0) {
        // print "X Y"
        for (i=0; i<len; i++) {
            Array_strvalue(x, i, xstr);
            Array_strvalue(v, i, vstr);
            fprintf(f, "%s %s\n", xstr, vstr);
        }
    } else { 
        // print "X: Y1 Y2 ... Y<ascii_width>"
        if (ascii_width < 0) ascii_width = -1 * ascii_width;
        i = 0;  // index in array
        while (i<len) {
            fprintf(f, "%d:",i);
            j = 0;  // number of values in one line
            while (j < ascii_width && i<len) {
                Array_strvalue(v, i, vstr);
                fprintf(f, " %s", vstr);
                j++;
                i++;
            }
            fprintf(f,"\n");
        }
    }
    
        
    fclose(f);
    free(fn);
    return 0;
}

static int print_data_2D(char *outnamespec, char *xname, char* yname, char *vname, Array x, Array y, Array v) {
    /* FIXME not yet written !*/
    char *fn;
    char outfile[256];
    FILE *f;
    int len = min(Array_length(x), Array_length(y));
    int i;
    char xstr[128], ystr[128];

    if (output_xml) 
        snprintf(outfile, 256, "%s.xml", outnamespec);
    else 
        snprintf(outfile, 256, "%s.txt", outnamespec);
    if (verbose) printf("    print data to %s\n", outfile);

    if ( outfile == NULL) {
        fn = strndup("/dev/stdout", 32);
        //printf ("-- print to stdout %s\n", fn);
    } else {
        fn = strndup(outfile, 256);
        //printf ("-- print to file %s\n", outfile);
    }

    if ((f = fopen(fn,"w")) == NULL) {
        fprintf(stderr, "Error at opening for writing file %s: %s\n",
                fn, strerror(errno));
        return 1;
    }


    if (output_xml){
        fprintf(f, "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n");
        fprintf(f, "<plot xname=\"%s\" yname=\"%s\">\n", xname, yname);
    }
        
    for (i=0; i<len; i++) {
        Array_strvalue(x, i, xstr);
        Array_strvalue(y, i, ystr);
        if (output_xml) fprintf(f,"  <point>\n    <X>");
        fprintf(f, "%s", xstr);
        if (output_xml) fprintf(f,"</X>\n    <Y>");
        else            fprintf(f," ");
        fprintf(f, "%s", ystr);
        if (output_xml) 
            fprintf(f,"</Y>\n  </point>\n");
        else
            fprintf(f,"\n");
    }
    
    if (output_xml) fprintf(f, "</plot>\n");
        
    fclose(f);
    free(fn);
    return 0;
}

static int str_to_int(char *str, char *complete_str) {
    int value;
    // convert item to number
    errno = 0;
    value = strtol(str, (char **)NULL, 0);
    if (errno) {
        //printf("\n");
        fprintf(stderr, "Error: could not convert field into a value: %s from \"%s\"\n", str, complete_str);
        exit(200);
    }
    return value;
}

// parse a string "0, t3; 027" into an integer array
// of [0,3,27] and return tDimidx as index of "t" dimension in the array
// exits if parsing failes
static void parseDimSpec(char *str, int *dims, bool allow_time, 
                        long *tDimidx, long *tValue, long *tStepping) 
{
    char *token, *saveptr;
    char *steppingstr;
    char *s;  // copy of s; strtok modifies the string
    int  i=0;

    if (tDimidx != NULL) *tDimidx = -1;
    s = strndup(str, 256);
    token = strtok_r(s, " ,;x\t\n", &saveptr);
    while (token != NULL && i < MAX_DIMS) {
        //printf("\t|%s|", token);

        // check for time dimension 
        if (token[0] == 't') {
            if (*tDimidx != -1) {
                fprintf(stderr, "Error: only one time dimension can be defined in \"%s\"\n", str);
                exit(200);
            }
            if (!allow_time) {
                fprintf(stderr, "Error: time specification is not allowed for this dimension specification: \"%s\"\n", str);
                exit(200);
            }
            *tDimidx = i;
            token++;
            //printf("TIME");
            // look for : separator for stepping info
            steppingstr = strchr(token, ':');
            if (steppingstr != NULL) {
                steppingstr[0] = '\0'; 
                // this puts \0 into token too! Token should contain the time value now
                if (steppingstr == NULL) {
                    fprintf(stderr, "Error: time dimension with stepping is ill defined in \"%s\". A number is needed too after the : like t0:2\n", str);
                    exit(200);
                }
                *tStepping = str_to_int(steppingstr, str);
            }
            if (token == NULL) {
                //printf("\n");
                fprintf(stderr, "Error: time dimension is ill defined in \"%s\". A number is needed too like t0\n", str);
                exit(200);
            }
            // finally get the value
            *tValue = str_to_int(token, str);
            dims[i] = *tValue;

        } else {
            // just a number
            dims[i] = str_to_int(token, str);
        }

        // get next item
        token = strtok_r(NULL, " ,;x\t\n", &saveptr);
        i++;
    }
    //if (i>0) printf("\n");

    // check if number of dims specified is larger than we can handle
    if (token != NULL) {
        fprintf(stderr, "Error: More dimensions specified in \"%s\" than we can handle (%d)\n", str, MAX_DIMS);
        exit(200);
    }
}

// parse a string "0, 255; 127" into an int[3] array
// exit if string does not conform (have exactly three values)
static void parseRGB(char *str, int rgb[3])
{
    char *token, *saveptr;
    char *s;  // copy of s; strtok modifies the string
    int  i=0;

    s = strndup(str, 256);
    token = strtok_r(s, " ,;x\t\n", &saveptr);
    //printf("Parse RGB string %s\n", s);
    while (token != NULL && i < 3) {
        //printf("\t|%s|", token);
        rgb[i] = str_to_int(token, str); // will exit if fails
        // sanity check
        if (rgb[i] != CUT_TO_BYTE(rgb[i])) {
            fprintf(stderr, "Warning: RGB value %d in \"%s\" is out of range 0..255. Will use %d\n", 
                    rgb[i], str, CUT_TO_BYTE(rgb[i]));
        }
        // get next item
        token = strtok_r(NULL, " ,;x\t\n", &saveptr);
        i++;
    }
    //if (i>0) printf("\n");
    // error checks
    if (i != 3) {
        fprintf(stderr, "Error: Less than 3 values are specified in \"%s\"\n", str);
        exit(200);
    }
    if (token != NULL) {
        fprintf(stderr, "Error: More than 3 values are specified in \"%s\"\n", str);
        exit(200);
    }
}
