/* HDF5 data reader for Array
 *
 * Copyright Oak Ridge National Laboratory 2009
 * Author: Norbert Podhorszki, pnorbert@ornl.gov
**/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <hdf5.h>
#include "readhdf5.h"

#define MAX_NAMELEN 512

// Global vars
static int ngroups;  // # of groups
static int nvars;    // # of vars (datasets)

/*
 * Define operator data structure type for H5Literate callback.
 * During recursive iteration, these structures will form a
 * linked list that can be searched for duplicate groups,
 * preventing infinite recursion.
 */
struct opdata {
    hid_t           file_id;        /* File id to be able to open datasets */
    unsigned        recurs;         /* Recursion level.  0=root */
    struct opdata   *prev;          /* Pointer to previous opdata */
    haddr_t         addr;           /* Group address */
    bool            count_only;     /* mode: count only or register each variable */
    VarInfo         *varinfo;       /* place for variable info */
    char            path[MAX_NAMELEN];      /* full path to group */
    char            *nameattr;      /* attribute that defines display name instead of path */
    char            *dispname;      /* display name if a group attribute matches nameattr, */
                                    /*   used only if variable does not have this attr */
};

/************************************************************

  This function recursively searches the linked list of
  opdata structures for one whose address matches
  target_addr.  Returns 1 if a match is found, and 0
  otherwise.

 ************************************************************/
static int group_check (struct opdata *od, haddr_t target_addr)
{
    if (od->addr == target_addr)
        return 1;       /* Addresses match */
    else if (!od->recurs)
        return 0;       /* Root group reached with no matches */
    else
        return group_check (od->prev, target_addr);
                        /* Recursively examine the next node */
}


static char* get_name_attr( hid_t loc_id, char *nameattr) {
    int i, n;
    char name[256];
    char *value = NULL;
    hid_t attr_id, type_id;
    size_t attr_size;
    herr_t herr;
    
    n = H5Aget_num_attrs (loc_id);
    //printf ("  attrs (%d):", n);
    for (i=0; i<n; i++) {
        attr_id = H5Aopen_idx (loc_id, i);
        H5Aget_name( attr_id, 256, name);
        //printf(" %s", name);
        if (!strcmp(name, nameattr)) {
            type_id = H5Aget_type (attr_id);
            attr_size = H5Tget_size(type_id);
            //printf("  attr %s id = %d  type=%d  size=%d\n", name, attr_id, type_id, (int)attr_size);
            value = (char *) malloc(attr_size);
            herr = H5Aread( attr_id, type_id, value);
            //printf("  attr %s id = %d  type=%d err=%d bytes, value=%s\n", name, attr_id, type_id, (int)herr, value);
            if (herr != 0) {
                fprintf(stderr,"Error: tried to read attribute %s but H5Aread() failed. herr_t=%d\n", 
                        nameattr, herr);
                free(value);
                value = NULL;
            }
        }
        H5Aclose (attr_id);
    }
    //printf("\n");
    return value;
}

/************************************************************

  Operator function.  This function prints the name and type
  of the object passed to it.  If the object is a group, it
  is first checked against other groups in its path using
  the group_check function, then if it is not a duplicate,
  H5Literate is called for that group.  This guarantees that
  the program will not enter infinite recursion due to a
  circular path in the file.

 ************************************************************/
static herr_t op_func (hid_t loc_id, const char *name, const H5L_info_t *info,
            void *operator_data)
{
    herr_t          status, return_val = 0;
    H5O_info_t      infobuf;
    struct opdata   *od = (struct opdata *) operator_data;
                                /* Type conversion */
    unsigned        spaces = 2*(od->recurs+1);
                                /* Number of whitespaces to prepend
                                   to output */
    hid_t           dataset, dataspace, datatype, t_native;
    H5T_class_t     t_class;        /* data type class */
    //H5T_order_t     order;          /* data order */
    size_t          size;
    int             ndims, status_n, i;
    hsize_t         dims[MAX_DIMS];
    char            fn[512];

    /*
     * Get type of the object and display its name and type.
     * The name of the object is passed to this function by
     * the Library.
     */
    status = H5Oget_info_by_name (loc_id, name, &infobuf, H5P_DEFAULT);
    if (verbose>1) printf ("%*s", spaces, "");     /* Format output */
    switch (infobuf.type) {
        case H5O_TYPE_GROUP:
            if (verbose>1) printf ("Group: %s {\n", name);

            /*
             * Check group address against linked list of operator
             * data structures.  We will always run the check, as the
             * reference count cannot be relied upon if there are
             * symbolic links, and H5Oget_info_by_name always follows
             * symbolic links.  Alternatively we could use H5Lget_info
             * and never recurse on groups discovered by symbolic
             * links, however it could still fail if an object's
             * reference count was manually manipulated with
             * H5Odecr_refcount.
             */
            if ( group_check (od, infobuf.addr) ) {
                fprintf (stderr, "hdf5 open warning: Loop detected for group %s!\n", name);
            }
            else {

                /*
                 * Initialize new operator data structure and
                 * begin recursive iteration on the discovered
                 * group.  The new opdata structure is given a
                 * pointer to the current one.
                 */
                struct opdata nextod;
                nextod.file_id = od->file_id;
                nextod.recurs = od->recurs + 1;
                nextod.prev = od;
                nextod.addr = infobuf.addr;
                nextod.count_only = od->count_only;
                nextod.varinfo = od->varinfo;
                nextod.nameattr = od->nameattr;
                nextod.dispname = NULL;
                snprintf(nextod.path, MAX_NAMELEN, "%s%s/", od->path, name);
                return_val = H5Literate_by_name (loc_id, name, H5_INDEX_NAME,
                            H5_ITER_NATIVE, NULL, op_func, (void *) &nextod,
                            H5P_DEFAULT);

                ngroups++;
            }
            if (verbose>1) printf ("%*s}\n", spaces, "");
            break;

        case H5O_TYPE_DATASET:
            if (verbose>1) printf ("Dataset: %s\n", name);
            if (!od->count_only) {
                snprintf(fn, MAX_NAMELEN, "%s%s", od->path, name);
                od->varinfo[nvars].name = strndup(fn, MAX_NAMELEN);
                if (od->nameattr != NULL) {
                    //printf (" check attribute: %s/%s\n", name, od->nameattr);
                    od->varinfo[nvars].dispname = get_name_attr( loc_id, od->nameattr );
                }
                if (od->varinfo[nvars].dispname == NULL) 
                    od->varinfo[nvars].dispname  = od->varinfo[nvars].name;  // default is full var path
                if (verbose>1) printf ("%*s  full name: %s\n", spaces, "", od->varinfo[nvars].name);
                dataset   = H5Dopen(loc_id, name, H5P_DEFAULT);
                //printf("  opened dataset: %d  loc_id=%d, name=%s\n", (int)dataset, (int)loc_id, name);
                datatype  = H5Dget_type(dataset); 
                //printf("  opened datatype: %d \n", (int)datatype);
                t_class   = H5Tget_class(datatype);
                //printf("  got t_class: %d \n", (int)t_class);
                size      = H5Tget_size(datatype);
                //printf("  got size: %d \n", (int)size);
                t_native  = H5Tget_native_type(datatype, H5T_DIR_ASCEND);
                //printf("  got native type: %d \n", (int)t_native);

                // Determine what data type we need to have in memory 
                if (H5Tequal(t_native, H5T_NATIVE_SCHAR) || 
                    H5Tequal(t_native, H5T_NATIVE_UCHAR)
                   ) 
                    od->varinfo[nvars].type = int8Array;
                else if (H5Tequal(t_native, H5T_NATIVE_SHORT) || 
                    H5Tequal(t_native, H5T_NATIVE_USHORT)
                   ) 
                    od->varinfo[nvars].type = int16Array;
                else if (H5Tequal(t_native, H5T_NATIVE_INT) || 
                         H5Tequal(t_native, H5T_NATIVE_UINT) ||
                         H5Tequal(t_native, H5T_NATIVE_LONG) ||
                         H5Tequal(t_native, H5T_NATIVE_ULONG)
                        ) 
                    od->varinfo[nvars].type = int32Array;
                else if (H5Tequal(t_native, H5T_NATIVE_LLONG) || 
                         H5Tequal(t_native, H5T_NATIVE_ULLONG)
                        )
                    od->varinfo[nvars].type = int64Array;
                else if (H5Tequal(t_native, H5T_NATIVE_FLOAT))
                    od->varinfo[nvars].type = floatArray;
                else if (H5Tequal(t_native, H5T_NATIVE_DOUBLE) ||
                         H5Tequal(t_native, H5T_NATIVE_LDOUBLE)
                        )
                    od->varinfo[nvars].type = doubleArray;
                else {
                        fprintf(stderr, "Variable %s has a type (%d) we cannot handle\n",
                                od->varinfo[nvars].name, (int)t_class);
                        od->varinfo[nvars].type = undefArray;
                }
                
                od->varinfo[nvars].varid = -1; // dataset is always a new int when reopened so cannot use it
                dataspace = H5Dget_space(dataset);
                ndims    = H5Sget_simple_extent_ndims(dataspace);
                if (ndims > MAX_DIMS) {
                    fprintf(stderr, "Error: variable %s: # of dimensions (%d) > max allowed (%d)."
                                    " Recompile plotter with larger reader.h:MAX_DIMS\n", 
                                    od->varinfo[nvars].name, ndims, MAX_DIMS);
                    ndims = MAX_DIMS;
                }
                status_n = H5Sget_simple_extent_dims(dataspace, dims, NULL);
                od->varinfo[nvars].ndims = ndims;
                for (i=0; i<ndims; i++) od->varinfo[nvars].dimsize[i] = (int)dims[i];
                if (verbose>1) { 
                    if (od->nameattr != NULL) 
                        printf ("%*s  display name: %s\n", spaces, "", od->varinfo[nvars].dispname);
                    printf("%*s  type = %s, size = %d, ndims = %d [", spaces, "",
                            arrayTypeStrings[od->varinfo[nvars].type], (int)size, (int)ndims);
                    for (i=0; i<ndims; i++) printf(" %d", (int)od->varinfo[nvars].dimsize[i]);
                    printf(" ]\n");
                }
                H5Sclose(dataspace);
                H5Tclose(datatype);
                H5Dclose(dataset);
            }
            nvars++;
            break;

        case H5O_TYPE_NAMED_DATATYPE:
            printf ("Datatype: %s\n", name);
            break;
        default:
            printf ( "Unknown: %s\n", name);
    }

    return return_val;
}


DataFile readhdf5_open(char *path, char *nameattr) {
    hid_t file_id;
    herr_t          status;
    H5O_info_t      infobuf;
    struct opdata   od;

    DataFile df = DataFile_new();
    
    if (verbose) printf("\nHDF5 open: traverse %s\n", path);
    
    // Open the hdf5 file
    file_id = H5Fopen(path, H5F_ACC_RDONLY, H5P_DEFAULT);
    if (file_id < 0) {
        fprintf(stderr, "readhdf5: error opening hdf5 file %s\n", path);
        exit(1);
    }

    // I. count the number of variables in the file (traverse with count_only=true)

    // Initialize the operator data structure.
    status = H5Oget_info (file_id, &infobuf);
    od.file_id = file_id;
    od.recurs = 0;
    od.prev = NULL;
    od.addr = infobuf.addr;
    od.count_only = true;
    od.varinfo = NULL;
    od.path[0] = '/'; od.path[1] = '\0'; //  / denotes root
    od.nameattr = nameattr;
    od.dispname = NULL;
    

    nvars = 0;
    
    // begin discovery iteration with the root group
    if (verbose>1) printf ("Count variables:\n");
    if (verbose>1) printf ("/ {\n");
    status = H5Literate (file_id, H5_INDEX_NAME, H5_ITER_NATIVE, 
                         NULL, op_func, (void *) &od);
    if (verbose>1) printf ("}\n");

    df.nvars      = nvars;

    if (verbose) printf("  groups=%d  vars=%d\n", ngroups, nvars);

    // II. register each variable by traversing again

    // create array for variables
    df.varinfo   = VarInfo_newarray(nvars);
    if (df.varinfo == NULL) {
        fprintf(stderr, "error allocating varinfo array, nvars=%d\n", nvars);
        exit(6);
    }

    // Initialize the operator data structure.
    status = H5Oget_info (file_id, &infobuf);
    od.recurs = 0;
    od.prev = NULL;
    od.addr = infobuf.addr;
    od.count_only = false;
    od.varinfo = df.varinfo;
    od.path[0] = '/'; od.path[1] = '\0'; //  / denotes root
    od.nameattr = nameattr;
    od.dispname = NULL;

    nvars = 0; // start again from 0 since this will be the index to od.vi
    
    // begin registration iteration with the root group
    if (verbose>1) printf ("Register variables:\n");
    if (verbose>1) printf ("/ {\n");
    status = H5Literate (file_id, H5_INDEX_NAME, H5_ITER_NATIVE, 
                         NULL, op_func, (void *) &od);
    if (verbose>1) printf ("}\n");


    df.fd = (int) file_id;
    return df;
}                

/** Close data file and free all allocated resources (names and varinfos) */
void  readhdf5_close(DataFile df) {
    herr_t err;
    err = H5Fclose( (hid_t)df.fd );
    if (err < 0) 
         fprintf(stderr, "error closing hdf5 file\n");
}   


/** read the data of one variable of one timestep.
  * The array will be initialized and allocated (so it should be freed manually after use).
  * On error: Array.type = undefArray;
*/
Array readhdf5_read_var( DataFile df, VarInfo vi, int *start, int *count) {
    hid_t           dataset, dataspace, datatype;
    hid_t           memspace, memtype;
    H5T_class_t     t_class;  // type of data       
    hsize_t         t_size;   // size of type t_class
    hid_t           t_native; // native type of type class
    herr_t          status;
    int             i;
    hsize_t         start_t[MAX_DIMS], count_t[MAX_DIMS], size;
    hsize_t         start_mem[1], count_mem[1];
    hsize_t         dimsm[1];    /* memory space dimensions */
    void            *data;
    Array           x = Array_new(undefArray);
    int             ndims, dims[MAX_DIMS]; // resulting array dimensions

    if (vi.type == undefArray) {
        fprintf(stderr, "readhdf5 read: data type of var %s is not supported\n", vi.name);
        Array_seterrno(x,-4);
        return x;
    }

    dataset   = H5Dopen( (hid_t) df.fd, vi.name, H5P_DEFAULT);
    datatype  = H5Dget_type(dataset); 
    t_class   = H5Tget_class(datatype);
    t_size    = H5Tget_size(datatype);
    t_native  = H5Tget_native_type(datatype, H5T_DIR_ASCEND);

    if (H5Tequal(t_native, H5T_NATIVE_SCHAR) || 
        H5Tequal(t_native, H5T_NATIVE_UCHAR)
       ) 
        memtype = H5T_NATIVE_UCHAR;
    else if (H5Tequal(t_native, H5T_NATIVE_SHORT) || 
        H5Tequal(t_native, H5T_NATIVE_USHORT)
       ) 
        memtype = H5T_NATIVE_SHORT;
    else if (H5Tequal(t_native, H5T_NATIVE_INT) || 
             H5Tequal(t_native, H5T_NATIVE_UINT) ||
             H5Tequal(t_native, H5T_NATIVE_LONG) ||
             H5Tequal(t_native, H5T_NATIVE_ULONG)
            ) 
        memtype = H5T_NATIVE_INT;
    else if (H5Tequal(t_native, H5T_NATIVE_LLONG) || 
             H5Tequal(t_native, H5T_NATIVE_ULLONG)
            )
        memtype = H5T_NATIVE_LLONG;
    else if (H5Tequal(t_native, H5T_NATIVE_FLOAT))
        memtype = H5T_NATIVE_FLOAT;
    else if (H5Tequal(t_native, H5T_NATIVE_DOUBLE) ||
             H5Tequal(t_native, H5T_NATIVE_LDOUBLE)
            )
        memtype = H5T_NATIVE_DOUBLE;
    else {
        fprintf(stderr, "Variable %s has a type (%d) we cannot handle\n",
                vi.name, (int)t_native);
        Array_setType(x, undefArray);
        H5Tclose(datatype);
        H5Dclose(dataset);
        return x;
    }

    // Define hyperslab in the dataset:  
    // create the counter arrays with the appropriate lengths
    // transfer start and count arrays to format dependent arrays
    size  = 1;
    ndims = 0;
    for (i=0; i<vi.ndims; i++) {
        if (start[i] < 0)  // negative index means last-|index|
            start_t[i] = (size_t) vi.dimsize[i]+start[i];
        else
            start_t[i] = (size_t) start[i];
        if (count[i] < 0)  // negative index means last-|index|+1-start
            count_t[i] = (size_t) vi.dimsize[i]+count[i]+1-start_t[i];
        else
            count_t[i] = (size_t) count[i];
        size *= count_t[i];
        if (count_t[i] > 1) {
            dims[ndims] = count_t[i];
            ndims++;
        }
        if (verbose>1) printf("    offset[%d]=%ld, count[%d]=%ld, size=%ld\n", 
                              i, (long)start_t[i], i, (long)count_t[i], (long)size);
    }

    /* FIXME: at this point we can have a dataspace with dimension > MAX_DIMS (variable passed through in op_func()) 
     *        while start and count are arrays only with MAX_DIMS length, 
     */
    dataspace = H5Dget_space(dataset);
    status = H5Sselect_hyperslab(dataspace, H5S_SELECT_SET, start_t, NULL, count_t, NULL);
    if (status < 0) {
        fprintf(stderr,"Error: readhdf5 read, hyperslab selection failed for var %s\n", vi.name);
        Array_setType(x, undefArray);
        Array_seterrno(x,-5);
        H5Tclose(datatype);
        H5Dclose(dataset);
        return x;
    }

    // Define the memory dataspace. [0..n]
    dimsm[0] = size;
    memspace = H5Screate_simple(1,dimsm,NULL);

    // Define memory hyperslab.     [0..n]
    start_mem[0] = 0;
    count_mem[0]  = dimsm[0];
    status = H5Sselect_hyperslab(memspace, H5S_SELECT_SET, start_mem, NULL, count_mem, NULL);
    
    // allocate array and get hold to it raw
    Array_setType(x, vi.type);
    if (verbose>1) {
        printf("    resulting array has %d dimensions: %d", ndims, dims[0]);
        for (i=1; i<ndims; i++) printf( "x%d", dims[i] );
        printf(" total size=%ld\n", (long)size);
    }
    //if (!Array_allocate(x, size)) {
    if (!Array_allocate_dims(x, ndims, dims)) {
        fprintf(stderr, "Error: readhdf5_read_var: could not allocate array of %d elements when reading variable %s\n", 
                (int)size, vi.name);
        Array_seterrno(x,-5);
        Array_setType(x, undefArray);
        H5Sclose(memspace);
        H5Sclose(dataspace);
        H5Tclose(datatype);
        H5Dclose(dataset);
        return x;
    }
    data = Array_getDataPointer(x);


    // read in variable 
    status = H5Dread(dataset, memtype, memspace, dataspace, H5P_DEFAULT, data);

    if (status < 0) {
        fprintf(stderr, "error reading data for variable %s\n", vi.name); 
        Array_seterrno(x,-6);
        Array_free(x);
    } else {

        //set undef value of HDF5 arrays
        // FIXME: it can be set for a hdf5 dataset individually
        Array_set_undef_value(x, 0.0);
    }
    
    H5Sclose(memspace);
    H5Sclose(dataspace);
    H5Tclose(datatype);
    H5Dclose(dataset);

    return x;
}

