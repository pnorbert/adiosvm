/* NetCDF data reader for Array
 *
 * Copyright Oak Ridge National Laboratory 2009
 * Author: Norbert Podhorszki, pnorbert@ornl.gov
**/


#include <netcdf.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "readcdf.h"

DataFile readcdf_open(char *path, char *nameattr) {
    int i, j;
    int ncid, status;
    // global cdf info
    int ndims;    // # of dims
    int nvars;    // # of vars
    int ngatts;   // # of global attrs
    int ncformat; // format of the file
    // unlimited dim
    int recid;                    // the unlimited dimension id
    size_t recs;                  // number of records in the unlimited dim
    char recname[NC_MAX_NAME+1];  // name of the unlimited dim
    // related to one cdf variable
    char name[NC_MAX_NAME+1];
    nc_type type;
    int dimids[NC_MAX_VAR_DIMS];
    int nvardims;     // # of dims of each variable
    int nvaratts;     // # of attributes, read in but not used
    size_t dimlen;

    DataFile df = DataFile_new();
    
    if (verbose) printf("\nNetCDF open: read header info from %s\n", path);
    
    // open the netcdf file
    status = nc_open(path, 0, &ncid);
    if (status != NC_NOERR) {
        fprintf(stderr, "readcdf: error opening netcdf file %s\n", path);
        exit(1);
    }

    // get global info
    status = nc_inq(ncid, &ndims, &nvars, &ngatts, &recid);
    if (status != NC_NOERR)  {
        fprintf(stderr, "cannot get global file info: %s\n", nc_strerror(status));
        exit(2);
    }

    status = nc_inq_format(ncid, &ncformat);
    if (status != NC_NOERR)  {
        fprintf(stderr, "cannot get file format: %s\n", nc_strerror(status));
        exit(3); 
    }

    // get info on the unlimited dimension
    if (recid != -1)  {
        // get unlimited dimension name and current length 
        status = nc_inq_dim(ncid, recid, recname, &recs);
        if (status != NC_NOERR) {
             fprintf(stderr, "error getting info on the unlimited dimension: %s\n",
                    nc_strerror(status));
            exit(5);
        }
    }

    df.nvars      = nvars;
    //df.timesteps  = recs;
    //df.timedimidx = recid;

    if (verbose) printf("  dims=%d  vars=%d  attrs=%d\n", ndims, nvars, ngatts );
    if (verbose>1 && recid != -1) 
        printf("  The unlimited dimension is: name=%s, id=%d, current size=%d\n",
                recname, recid, (int)recs);

    // get variable info
    df.varinfo   = VarInfo_newarray(nvars);
    if (df.varinfo == NULL) {
        fprintf(stderr, "error allocating varinfo array, nvars=%d\n", nvars);
        exit(6);
    }

    for (i=0; i<nvars; i++) {
        // get type, # of dims, dimensions ids, # of attrs 
        status = nc_inq_var(ncid, i, name, &type, &nvardims, dimids, &nvaratts);
        if (status != NC_NOERR) {
            fprintf(stderr, "error getting variable %d %s: %s\n",
                    i, name, nc_strerror(status));
            exit(6); 
            }
        if (verbose>1) printf("  var: %s\tdims=%d (", name, nvardims);
        df.varinfo[i].name  = strdup(name);
        df.varinfo[i].dispname  = df.varinfo[i].name;  // default is full var path
        df.varinfo[i].varid = i;
        df.varinfo[i].ndims = nvardims;
        //df.varinfo[i].timedim = -1;  // may be set below 
        switch(type) {
            case NC_BYTE:
            case NC_CHAR:
                df.varinfo[i].type = int8Array;
                break;
            case NC_SHORT:
                df.varinfo[i].type = int16Array;
                break;
            case NC_INT:
                df.varinfo[i].type = int32Array;
                break;
            case NC_FLOAT:
                df.varinfo[i].type = floatArray;
                break;
            case NC_DOUBLE:
                df.varinfo[i].type = doubleArray;
                break;
            default:
                fprintf(stderr, "Type %d of NetCDF files not supported in plotter. var=%s\n", type, name);
                df.varinfo[i].type = undefArray;
                break;
        }
        for (j=0; j<nvardims; j++) { 
             // get dimension length
             status = nc_inq_dimlen(ncid, dimids[j], &dimlen);
             df.varinfo[i].dimsize[j] = dimlen;
             // check if this is the time dimension
             /*
             if (dimids[j] == recid) {
                 df.varinfo[i].timedim = j;
                 if (verbose) printf("T-");
             }
             */
             if (verbose>1) printf("%d ", (int)dimlen);
        }
        if (verbose>1) printf(")\n");
    }

    df.fd = ncid;
    return df;
}                

/** Close data file and free all allocated resources (names and varinfos) */
void  readcdf_close(DataFile df) {
    if (nc_close(df.fd) != NC_NOERR) 
         fprintf(stderr, "error closing netcdf file\n");
}   


/** read the data of one variable of one timestep.
  * The array will be initialized and allocated (so it should be freed manually after use).
  * On error: Array.type = undefArray;
*/
Array readcdf_read_var( DataFile df, VarInfo vi, int *start, int *count) {
    Array x = Array_new(undefArray);
    int i;
    // to check data type
    int status;
    nc_type vartype;
    ArrayType atype;
    // to read data
    size_t start_t[NC_MAX_VAR_DIMS], count_t[NC_MAX_VAR_DIMS], size;
    void *data;
    int  ndims, dims[MAX_DIMS]; // resulting array dimensions

    // check dimensions: we can read only 1 dimension 
    /*
    if ( (vi.timedim == -1 && vi.ndims > 1) || vi.ndims > 2) {
        fprintf(stderr, "Error: readcdf_read_var: We can read only 1D arrays or 2D arrays with time "
                "dimension. Var %s has %d dimensions.\n", vi.name, vi.ndims);
        Array_seterrno(x,-2);
        return x;
    }
    */
    
    // get type of var again from the netcdf file directly 
    // and set the array accordingly
    status = nc_inq_vartype(df.fd, vi.varid, &vartype);
    switch(vartype) {
        case NC_BYTE:
        case NC_CHAR:
            atype = int8Array;
            break;
        case NC_SHORT:
            atype = int16Array;
            break;
        case NC_INT:
            atype = int32Array;
            break;
        case NC_FLOAT:
            atype = floatArray;
            break;
        case NC_DOUBLE:
            atype = doubleArray;
            break;
        default:
            fprintf(stderr, "Error: readcdf_read_var: Type %d of NetCDF files not supported in plotter. var=%s\n", 
                    vartype, vi.name);
            Array_seterrno(x,-3);
            return x;
            break;
    }
    Array_setType(x, atype);

    // debug 
    //printf("-- debug: type of array x should be %s\n", arrayTypeStrings[atype]);
    //printf("-- debug: type of array x is %s\n", arrayTypeStrings[Array_getType(x)]);

    // create the counter arrays with the appropriate lengths
    // transfer start and count arrays to format dependent arrays
    size  = 1;
    ndims = 0;
    for (i=0; i<vi.ndims; i++) {
        if (start[i] < 0)  // negative index means last-|index|
            start_t[i] = (size_t) vi.dimsize[i]+start[i];
        else
            start_t[i] = (size_t) start[i];
        if (count[i] < 0)  // negative index means last-|index|+1-start
            count_t[i] = (size_t) vi.dimsize[i]+count[i]+1-start_t[i];
        else
            count_t[i] = (size_t) count[i];
        size *= count_t[i];
        if (count_t[i] > 1) {
            dims[ndims] = count_t[i];
            ndims++;
        }
        if (verbose>1) printf("    s[%d]=%ld, c[%d]=%ld, size=%ld\n", i, start_t[i], i, count_t[i], size);
    }
    
    if (verbose>1) {
        printf("    resulting array has %d dimensions: %d", ndims, dims[0]);
        for (i=1; i<ndims; i++) printf( "x%d", dims[i] );
        printf(" total size=%ld\n", (long)size);
    }

    // allocate array and get hold to it raw
    //if (!Array_allocate(x, size)) {
    if (!Array_allocate_dims(x, ndims, dims)) {
        fprintf(stderr, "Error: readcdf_read_var: could not allocate array of %d elements when reading variable %s\n", 
                (int)size, vi.name);
        Array_seterrno(x,-5);
        return x;
    }
    data = Array_getDataPointer(x);

    // read in variable (1D slice)
    switch(vartype) {
        case NC_SHORT:
            status = nc_get_vara_short(df.fd, vi.varid, start_t, count_t, (short*)data);
            break;
        case NC_INT:   
            status = nc_get_vara_int(df.fd, vi.varid, start_t, count_t, (int*)data);
            break;
        case NC_FLOAT: 
            status = nc_get_vara_float(df.fd, vi.varid, start_t, count_t, (float*)data);
            break;
        case NC_DOUBLE: 
            status = nc_get_vara_double(df.fd, vi.varid, start_t, count_t, (double*)data);
            break; 
        case NC_BYTE:
            status = nc_get_vara_schar(df.fd, vi.varid, start_t, count_t, (signed char*)data);
            break; 
        case NC_CHAR:
            status = nc_get_vara_uchar(df.fd, vi.varid, start_t, count_t, (unsigned char*)data);
            break; 
        default: ;
    }

    if (status != NC_NOERR) {
        fprintf(stderr, "error reading data for variable %d %s: %s\n",
               vi.varid, vi.name, nc_strerror(status));
        Array_seterrno(x,-6);
        Array_free(x);
        return x;
    }

    //set undef value of NetCDF arrays
    // FIXME: it can be set for a netcdf file individually as a global attribute, so it should be checked.
    Array_set_undef_value(x, NC_FILL_DOUBLE);
    
    return x;
}

