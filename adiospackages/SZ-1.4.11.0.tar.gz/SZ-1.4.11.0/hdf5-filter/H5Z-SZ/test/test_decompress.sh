#!/bin/bash
echo dszFromHDF5 ../../../example/testdata/x86/testfloat_8_8_128.dat.sz.h5
dszFromHDF5 ../../../example/testdata/x86/testfloat_8_8_128.dat.sz.h5

