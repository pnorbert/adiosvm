#!/bin/bash

./test_conf
./test_ByteToolkit
./test_dataCompression
./test_DynamicByteArray
./test_DynamicIntArray
./test_DynamicFloatArray
./test_DynamicDoubleArray
./test_Huffman
./test_rw
./test_TypeManager
