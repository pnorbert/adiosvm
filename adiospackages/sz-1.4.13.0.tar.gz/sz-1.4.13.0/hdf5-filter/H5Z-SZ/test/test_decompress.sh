#!/bin/bash
echo dszFromHDF5 ../../../example/testdata/x86/testfloat_8_8_128.dat.sz.h5
dszFromHDF5 ../../../example/testdata/x86/testfloat_8_8_128.dat.sz.h5
echo dszFromHDF5 ../../../example/testdata/x86/testdouble_8_8_128.dat.sz.h5
dszFromHDF5 ../../../example/testdata/x86/testdouble_8_8_128.dat.sz.h5
echo dszFromHDF5 ../../../example/testdata/x86/testint8_8x8x8.dat.sz.h5
dszFromHDF5 ../../../example/testdata/x86/testint8_8x8x8.dat.sz.h5
echo dszFromHDF5 ../../../example/testdata/x86/testint16_8x8x8.dat.sz.h5
dszFromHDF5 ../../../example/testdata/x86/testint16_8x8x8.dat.sz.h5
echo dszFromHDF5 ../../../example/testdata/x86/testint32_8x8x8.dat.sz.h5
dszFromHDF5 ../../../example/testdata/x86/testint32_8x8x8.dat.sz.h5
echo dszFromHDF5 ../../../example/testdata/x86/testint64_8x8x8.dat.sz.h5
dszFromHDF5 ../../../example/testdata/x86/testint64_8x8x8.dat.sz.h5
