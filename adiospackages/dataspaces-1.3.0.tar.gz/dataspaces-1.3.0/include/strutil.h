#ifndef __STRUTIL_H_
#define __STRUTIL_H_

size_t str_len(const char *str);
char *str_append_const(char *, const char *);
char *str_append(char *, char *);

#endif
