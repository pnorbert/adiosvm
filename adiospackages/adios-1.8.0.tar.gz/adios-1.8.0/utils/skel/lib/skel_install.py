#!/usr/bin/env python

import skel_settings

def main(argv=None):
    skel_settings.create_settings_dir_if_needed()


if __name__ == "__main__":
    main()
