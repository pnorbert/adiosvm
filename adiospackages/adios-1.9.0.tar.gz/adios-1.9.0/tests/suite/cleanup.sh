#!/bin/bash
#
# Deletes all test logs and work dirs in .
#

set -v
rm -rf log.* work.*

