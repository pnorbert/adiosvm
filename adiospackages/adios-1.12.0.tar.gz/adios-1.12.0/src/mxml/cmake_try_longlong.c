#include <stdint.h>

void main()
{
    long long int a = 0LL;
}
