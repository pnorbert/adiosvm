/**
 * cfg.h
 *
 *  Created on: Sep 4, 2013
 *  Author: Magda Slawinska aka Magic Magg magg dot gatech at gmail.com
 */

#ifndef CFG_H_
#define CFG_H_

//! size of the X dimension
#define NX_DIM 10


#endif /* CFG_H_ */
