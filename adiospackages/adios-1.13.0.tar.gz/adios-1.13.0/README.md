ADIOS (Adaptable I/O System) 
----------------------------

Please look at the examples/ directory for the example codes on how to 
use ADIOS. If you need more detailed information, please, read the User's 
manual.

Please read COPYING for the copyright. 

This release contains only a limited set of transport methods for different
I/O uses. There are more methods, actively researched ones, available.
Contact us to get them.




