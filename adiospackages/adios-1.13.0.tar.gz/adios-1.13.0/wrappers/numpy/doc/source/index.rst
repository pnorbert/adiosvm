.. Adios Python documentation master file, created by
   sphinx-quickstart on Fri May  8 10:13:24 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Adios Python
============

This Adios Python is a Python wrapper to Adios.


Quick Start Guide
-----------------

.. toctree::
   :maxdepth: 2

   quick
   build
   gallery
   ref

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

